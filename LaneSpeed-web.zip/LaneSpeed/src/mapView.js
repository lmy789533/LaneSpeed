// Canvas map view: the same drawing policy as native-macos/Sources/MapView.swift.
//
// Deliberately only talks to a duck-typed 2D context, so the browser, Electron and the Node
// pixel tests all exercise exactly the same code.

import {
  Handedness, LayerFilter, MapDocument, directionTitle, handednessTitle, layerMatches,
  lengthOf, niceStep, pointOn,
} from "../../core/src/index.js";

export const THEME = {
  background: [17, 24, 33],
  straight: [20, 163, 163],
  left: [245, 158, 43],
  right: [117, 109, 240],
  unmarked: [122, 143, 163],
  yellow: [255, 204, 0],
  pink: [255, 45, 85],
  white: [255, 255, 255],
  panel: [10, 15, 23],
  chipChanged: [26, 23, 5],
  chipNormal: [13, 20, 28],
};

export function laneColour(direction) {
  switch (direction) {
    case "straight": return THEME.straight;
    case "left": return THEME.left;
    case "right": return THEME.right;
    default: return THEME.unmarked;
  }
}

export function rgba(colour, alpha = 1) {
  return `rgba(${colour[0]}, ${colour[1]}, ${colour[2]}, ${alpha})`;
}

function mix(colour, other, fraction) {
  return colour.map((channel, index) => Math.round(channel + (other[index] - channel) * fraction));
}

export function createStats() {
  return {
    lanesDrawn: 0, lanesCulled: 0, arrows: 0, speedLabels: 0, conflictMarks: 0,
    changedInView: 0, thinLines: 0, changedThin: 0,
  };
}

function roundRectPath(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

/**
 * The map view: camera, rendering policy, hit testing and hover/selection handling.
 *
 * `bounds` is the logical size in CSS pixels; the caller sets up any device-pixel scaling.
 */
export class MapView {
  static FIT_MARGIN = 8;
  static MIN_SCALE = 1e-7;
  static MAX_SCALE = 200;
  static LAYER_OFFSET = 5;
  static SUB_PIXEL_WIDTH = 1.6;

  constructor(options = {}) {
    this.width = options.width ?? 800;
    this.height = options.height ?? 600;
    this.document = null;
    this.scale = 1;
    this.offsetX = 0;
    this.offsetY = 0;
    this.framing = null;
    this.selectedID = null;
    this.hoverID = null;
    this.changedIDs = new Set();
    this.onlyChanged = false;
    this.layerFilter = LayerFilter.BOTH;
    this.separateLayers = false;
    this.showSpeed = true;
    this.showDirection = true;
    this.showFill = true;
    this.showGrid = true;
    this.showReadout = true;
    this.subPixelWidth = MapView.SUB_PIXEL_WIDTH;
    this.effectiveSpeed = (lane) => lane.originalSpeed;
    this.onSelect = options.onSelect ?? (() => {});
    this.onHover = options.onHover ?? (() => {});
    this.stats = createStats();
    this._chipCache = new Map();
  }

  setSize(width, height) {
    this.width = Math.max(1, width);
    this.height = Math.max(1, height);
    this.applyFraming();
  }

  setDocument(document) {
    this.document = document;
    this.fit();
  }

  setLayerFilter(filter) {
    this.layerFilter = filter;
  }

  // MARK: - Camera

  get fittedScale() {
    if (!this.document?.bounds) return 1;
    return MapView.scaleToFit(this.document.bounds, this.width, this.height, MapView.FIT_MARGIN);
  }

  get zoomMultiple() {
    const fitted = this.fittedScale;
    return fitted > 0 ? this.scale / fitted : 1;
  }

  get visibleExtent() {
    return { width: this.width / this.scale, height: this.height / this.scale };
  }

  get worldRect() {
    return {
      minX: (0 - this.offsetX) / this.scale,
      minY: (0 - this.offsetY) / this.scale,
      maxX: (this.width - this.offsetX) / this.scale,
      maxY: (this.height - this.offsetY) / this.scale,
    };
  }

  static scaleToFit(box, width, height, margin) {
    if (!box || !(box.width >= 0) || !(box.height >= 0) || width <= 0 || height <= 0) return 1;
    const safeWidth = Math.max(box.width, 0.001);
    const safeHeight = Math.max(box.height, 0.001);
    const raw = Math.min(Math.max(width - margin * 2, 1) / safeWidth, Math.max(height - margin * 2, 1) / safeHeight);
    return Math.min(Math.max(raw, MapView.MIN_SCALE), MapView.MAX_SCALE);
  }

  fit() {
    this.fitTo(this.document?.bounds ?? null, MapView.FIT_MARGIN);
  }

  /** Frames a world box. The request is remembered so a resize keeps the same framing. */
  fitTo(box, margin = MapView.FIT_MARGIN) {
    if (!box) {
      this.framing = null;
      return;
    }
    this.framing = { box, margin };
    this.applyFraming();
  }

  applyFraming() {
    if (!this.framing) return;
    const { box, margin } = this.framing;
    this.scale = MapView.scaleToFit(box, this.width, this.height, margin);
    this.offsetX = this.width / 2 - ((box.minX + box.maxX) / 2) * this.scale;
    this.offsetY = this.height / 2 - ((box.minY + box.maxY) / 2) * this.scale;
  }

  focusLane(lane) {
    if (lane?.bounds) this.fitTo(lane.bounds, 30);
  }

  focusLanes(lanes) {
    const box = unionOf(lanes);
    if (box) this.fitTo(box, 34);
  }

  zoomBy(factor, point) {
    if (!Number.isFinite(factor) || factor <= 0) return;
    const next = Math.min(Math.max(this.scale * factor, MapView.MIN_SCALE), MapView.MAX_SCALE);
    if (next === this.scale) return;
    const ratio = next / this.scale;
    this.offsetX = point.x - (point.x - this.offsetX) * ratio;
    this.offsetY = point.y - (point.y - this.offsetY) * ratio;
    this.scale = next;
    this.framing = null;
  }

  zoomAroundCentre(factor) {
    this.zoomBy(factor, { x: this.width / 2, y: this.height / 2 });
  }

  /** Screen position (CSS pixels) of a world point. Screen y grows downwards. */
  project(point) {
    return { x: point.x * this.scale + this.offsetX, y: this.height - (point.y * this.scale + this.offsetY) };
  }

  unproject(point) {
    return { x: (point.x - this.offsetX) / this.scale, y: (this.height - point.y - this.offsetY) / this.scale };
  }

  lanesInView(lanes) {
    const rect = this.worldRect;
    return lanes.filter((lane) => lane.bounds && lane.bounds.minX <= rect.maxX && lane.bounds.maxX >= rect.minX
      && lane.bounds.minY <= rect.maxY && lane.bounds.maxY >= rect.minY);
  }

  // MARK: - Review helpers

  /**
   * Frames edited lanelets for review. A handful of edits is framed whole so every change stays
   * visible; a large set is zoomed in far enough that the numbers can be read.
   */
  review(lanes, overviewLimit = 30) {
    const usable = lanes.filter((lane) => lane.bounds && lane.averageWidth > 0);
    if (usable.length === 0) {
      this.fit();
      return false;
    }
    if (usable.length <= overviewLimit) {
      this.fitTo(unionOf(usable), 34);
      return this.isReadable(usable);
    }
    return this.fitReadable(usable);
  }

  fitReadable(lanes, minimumLaneWidth = 14) {
    const usable = lanes.filter((lane) => lane.bounds && lane.averageWidth > 0 && lane.labelPoint);
    if (usable.length === 0) {
      this.fit();
      return false;
    }
    const box = unionOf(usable);
    const median = medianOf(usable.map((lane) => lane.averageWidth));
    this.fitTo(box, 34);
    if (this.scale * median < minimumLaneWidth) {
      // The middle of the bounding box of lanelets spread over a district is usually empty
      // ground, which would zoom into nothing at all; aim at the busiest cluster instead.
      // The 2% margin matters: aiming exactly at the threshold can land a hair below it after
      // rounding and report "unreadable" for a view that is already perfectly readable.
      const anchor = this.densestCentre(usable, box) ?? { x: (box.minX + box.maxX) / 2, y: (box.minY + box.maxY) / 2 };
      this.zoomBy(Math.min((minimumLaneWidth * 1.02) / (median * this.scale), 80), this.project(anchor));
    }
    return this.isReadable(usable, minimumLaneWidth);
  }

  isReadable(lanes, minimumLaneWidth = 14) {
    if (lanes.length === 0 || this.lanesInView(lanes).length === 0) return false;
    return this.scale * medianOf(lanes.map((lane) => lane.averageWidth)) >= minimumLaneWidth;
  }

  densestCentre(lanes, box) {
    const side = Math.max(Math.max(box.width, box.height) / 20, 1);
    const cells = new Map();
    for (const lane of lanes) {
      if (!lane.labelPoint) continue;
      const key = `${Math.floor((lane.labelPoint.x - box.minX) / side)},${Math.floor((lane.labelPoint.y - box.minY) / side)}`;
      const entry = cells.get(key) ?? { count: 0, x: 0, y: 0 };
      entry.count += 1;
      entry.x += lane.labelPoint.x;
      entry.y += lane.labelPoint.y;
      cells.set(key, entry);
    }
    let best = null;
    for (const entry of cells.values()) if (!best || entry.count > best.count) best = entry;
    if (!best || best.count === 0) return null;
    return { x: best.x / best.count, y: best.y / best.count };
  }

  // MARK: - Rendering

  /** Screen shift applied to a lanelet so two coincident layers can be told apart. */
  shiftFor(lane) {
    if (!this.separateLayers || this.layerFilter !== LayerFilter.BOTH || lane.handedness !== Handedness.REVERSED) {
      return { x: 0, y: 0 };
    }
    const path = lane.centerline;
    if (path.length < 2) return { x: 0, y: 0 };
    const a = this.project(path[0]);
    const b = this.project(path[path.length - 1]);
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const length = Math.hypot(dx, dy) || 1;
    // perpendicular to travel, in screen space
    return { x: (-dy / length) * MapView.LAYER_OFFSET, y: (dx / length) * MapView.LAYER_OFFSET };
  }

  drawPath(ctx, points, shift = { x: 0, y: 0 }, close = false) {
    if (points.length === 0) return;
    ctx.beginPath();
    for (const [index, point] of points.entries()) {
      const screen = this.project(point);
      const x = screen.x + shift.x;
      const y = screen.y + shift.y;
      if (index === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    if (close) ctx.closePath();
  }

  measure(ctx, text, font) {
    ctx.font = font;
    return ctx.measureText(text).width;
  }

  chipMetrics(ctx, text, style) {
    const key = `${text}|${style.font}|${style.paddingX}|${style.paddingY}`;
    const cached = this._chipCache.get(key);
    if (cached) return cached;
    const width = Math.ceil(this.measure(ctx, text, style.font)) + style.paddingX * 2;
    const height = (style.fontSize ?? 11) + style.paddingY * 2 + 3;
    const metrics = { width, height };
    this._chipCache.set(key, metrics);
    return metrics;
  }

  drawChip(ctx, text, centre, style) {
    const { width, height } = this.chipMetrics(ctx, text, style);
    const x = centre.x - width / 2;
    const y = centre.y - height / 2;
    roundRectPath(ctx, x, y, width, height, 3.5);
    ctx.fillStyle = style.background;
    ctx.fill();
    if (style.border) {
      ctx.strokeStyle = style.border;
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.font = style.font;
    ctx.fillStyle = style.text;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(text, x + style.paddingX, y + height / 2 + 0.5);
    return { x, y, width, height };
  }

  /** Draws everything and returns the counters for the frame. */
  render(ctx) {
    this.stats = createStats();
    this._chipCache.clear();
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, this.width, this.height);
    ctx.clip();
    ctx.fillStyle = rgba(THEME.background);
    ctx.fillRect(0, 0, this.width, this.height);
    this.drawGrid(ctx);
    const lanes = this.drawLanes(ctx);
    if (this.showDirection) this.drawArrows(ctx, lanes);
    if (this.showSpeed) this.drawSpeedLabels(ctx, lanes);
    if (this.showReadout) this.drawOverlays(ctx);
    ctx.restore();
    return this.stats;
  }

  drawGrid(ctx) {
    if (!this.showGrid || this.scale <= 0) return;
    const world = this.worldRect;
    const spacing = niceStep(90 / this.scale);
    const screenSpacing = spacing * this.scale;
    if (!(spacing > 0) || screenSpacing < 6) return;
    ctx.beginPath();
    let x = Math.floor(world.minX / spacing) * spacing;
    while (x <= world.maxX) {
      const screen = this.project({ x, y: 0 });
      const px = Math.round(screen.x) + 0.5;
      ctx.moveTo(px, 0);
      ctx.lineTo(px, this.height);
      x += spacing;
    }
    let y = Math.floor(world.minY / spacing) * spacing;
    while (y <= world.maxY) {
      const screen = this.project({ x: 0, y });
      const py = Math.round(screen.y) + 0.5;
      ctx.moveTo(0, py);
      ctx.lineTo(this.width, py);
      y += spacing;
    }
    ctx.strokeStyle = rgba(THEME.white, 0.05);
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  /** Fills, outlines and layer separation. Returns the drawn lanelets with their screen boxes. */
  drawLanes(ctx) {
    const drawn = [];
    if (!this.document) return drawn;
    for (const lane of this.document.lanes) {
      if (this.onlyChanged && !this.changedIDs.has(lane.id)) continue;
      if (!layerMatches(this.layerFilter, lane.handedness)) continue;
      if (lane.polygon.length < 4 || !lane.bounds) continue;
      const box = this.screenBox(lane.bounds);
      if (box.maxX < -3 || box.minX > this.width + 3 || box.maxY < -3 || box.minY > this.height + 3) {
        this.stats.lanesCulled += 1;
        continue;
      }
      const changed = this.changedIDs.has(lane.id);
      if (changed) this.stats.changedInView += 1;
      this.stats.lanesDrawn += 1;
      drawn.push({ lane, box });
      const emphasised = lane.id === this.selectedID || lane.id === this.hoverID;
      if (emphasised) continue; // painted last, on top of everything
      const width = lane.averageWidth * this.scale;
      const shift = this.shiftFor(lane);
      const colour = laneColour(lane.direction);
      if (width < this.subPixelWidth && lane.centerline.length >= 2) {
        // Far out, a filled polygon would be thinner than a pixel: draw the one line a driver
        // would follow. Overlapping sub-pixel fills are what made the full map unreadable.
        this.drawPath(ctx, lane.centerline, shift);
        ctx.strokeStyle = rgba(changed ? THEME.yellow : colour, 0.92);
        ctx.lineWidth = changed ? 1.9 : 1.1;
        ctx.lineCap = "round";
        if (lane.handedness === Handedness.REVERSED && shift.x === 0 && shift.y === 0) ctx.setLineDash([4, 3]);
        ctx.stroke();
        ctx.setLineDash([]);
        if (changed) this.stats.changedThin += 1;
        if (lane.boundsDisagree) {
          this.drawPath(ctx, lane.centerline, shift);
          ctx.strokeStyle = rgba(THEME.pink, 0.95);
          ctx.lineWidth = 2.6;
          ctx.setLineDash([3, 3]);
          ctx.stroke();
          ctx.setLineDash([]);
          this.stats.conflictMarks += 1;
        }
        this.stats.thinLines += 1;
        continue;
      }
      this.drawPath(ctx, lane.polygon, shift, true);
      if (this.showFill) {
        const t = Math.min(Math.max((width - 3) / 60, 0), 1);
        ctx.fillStyle = rgba(colour, changed ? 0.55 - 0.26 * t : 0.46 - 0.31 * t);
        ctx.fill();
      }
      ctx.strokeStyle = rgba(colour, 0.95);
      ctx.lineWidth = changed ? 1.9 : 0.9;
      if (lane.handedness === Handedness.REVERSED && shift.x === 0 && shift.y === 0) ctx.setLineDash([6, 4]);
      ctx.stroke();
      ctx.setLineDash([]);
      if (changed) {
        this.drawPath(ctx, lane.polygon, shift, true);
        ctx.strokeStyle = rgba(THEME.yellow, 0.85);
        ctx.lineWidth = 2.4;
        ctx.stroke();
      }
      if (lane.boundsDisagree) {
        this.drawPath(ctx, lane.polygon, shift, true);
        ctx.strokeStyle = rgba(THEME.pink, 0.9);
        ctx.lineWidth = 1.6;
        ctx.stroke();
        this.stats.conflictMarks += 1;
      }
    }
    for (const id of [this.hoverID, this.selectedID]) {
      const entry = id === null ? undefined : drawn.find((item) => item.lane.id === id);
      if (!entry) continue;
      const selected = id === this.selectedID;
      this.drawPath(ctx, entry.lane.polygon, this.shiftFor(entry.lane), true);
      ctx.fillStyle = rgba(THEME.white, selected ? 0.22 : 0.12);
      ctx.fill();
      ctx.strokeStyle = rgba(THEME.white);
      ctx.lineWidth = selected ? 3 : 2;
      ctx.stroke();
    }
    return drawn;
  }

  screenBox(bounds) {
    const a = this.project({ x: bounds.minX, y: bounds.minY });
    const b = this.project({ x: bounds.maxX, y: bounds.maxY });
    return {
      minX: Math.min(a.x, b.x), maxX: Math.max(a.x, b.x),
      minY: Math.min(a.y, b.y), maxY: Math.max(a.y, b.y),
      get width() { return this.maxX - this.minX; },
      get height() { return this.maxY - this.minY; },
    };
  }

  drawArrowhead(ctx, point, direction, size, colour) {
    const length = Math.hypot(direction.x, direction.y);
    if (!(length > 1e-4)) return;
    const ux = direction.x / length;
    const uy = direction.y / length;
    const nx = -uy;
    const ny = ux;
    ctx.beginPath();
    ctx.moveTo(point.x - ux * size * 1.1, point.y - uy * size * 1.1);
    ctx.lineTo(point.x + ux * size * 0.1, point.y + uy * size * 0.1);
    ctx.strokeStyle = rgba(colour, 0.78);
    ctx.lineWidth = Math.max(size * 0.22, 1.4);
    ctx.lineCap = "round";
    ctx.stroke();
    const tip = { x: point.x + ux * size * 0.6, y: point.y + uy * size * 0.6 };
    const tail = { x: point.x - ux * size * 0.4, y: point.y - uy * size * 0.4 };
    const half = size * 0.34;
    ctx.beginPath();
    ctx.moveTo(tip.x, tip.y);
    ctx.lineTo(tail.x + nx * half, tail.y + ny * half);
    ctx.lineTo(tail.x - nx * half, tail.y - ny * half);
    ctx.closePath();
    ctx.fillStyle = rgba(colour);
    ctx.fill();
    ctx.strokeStyle = "rgba(0, 0, 0, 0.55)";
    ctx.lineWidth = 0.8;
    ctx.stroke();
  }

  /** One arrow per stretch of lane, pointing the way the lanelet is really driven. */
  drawArrows(ctx, lanes) {
    for (const { lane, box } of lanes) {
      const points = MapDocument.travelPath(lane);
      if (points.length < 2) continue;
      if (Math.max(box.width, box.height) < 26) continue;
      const shift = this.shiftFor(lane);
      const line = points.map((point) => {
        const screen = this.project(point);
        return { x: screen.x + shift.x, y: screen.y + shift.y };
      });
      const total = lengthOf(line);
      if (total < 30) continue;
      const emphasised = lane.id === this.selectedID || lane.id === this.hoverID;
      const spacing = 130;
      const distances = [];
      if (total <= spacing) distances.push(total * 0.5);
      else for (let distance = spacing * 0.5; distance < total; distance += spacing) distances.push(distance);
      const anchor = lane.labelPoint ? (() => {
        const screen = this.project(lane.labelPoint);
        return { x: screen.x + shift.x, y: screen.y + shift.y };
      })() : null;
      const colour = emphasised ? THEME.white : mix(laneColour(lane.direction), THEME.white, 0.45);
      for (const distance of distances) {
        const hit = pointOn(line, distance);
        if (!hit) continue;
        if (anchor && Math.hypot(hit.point.x - anchor.x, hit.point.y - anchor.y) < (this.showSpeed ? 26 : 0)) continue;
        this.drawArrowhead(ctx, hit.point, hit.direction, emphasised ? 15 : 13, colour);
        this.stats.arrows += 1;
      }
    }
  }

  /** Current speed written on the lane itself; edited lanelets are always labelled. */
  drawSpeedLabels(ctx, lanes) {
    const allowChangedOverflow = this.stats.changedInView <= 400;
    for (const { lane, box } of lanes) {
      const changed = this.changedIDs.has(lane.id);
      const emphasised = lane.id === this.selectedID || lane.id === this.hoverID;
      if (!emphasised && !changed && (box.width < 22 || box.height < 16)) continue;
      if (!lane.labelPoint) continue;
      const shift = this.shiftFor(lane);
      const screen = this.project(lane.labelPoint);
      const anchor = { x: screen.x + shift.x, y: screen.y + shift.y };
      const text = String(this.effectiveSpeed(lane) ?? lane.originalSpeed ?? "—");
      const style = {
        background: rgba(changed ? THEME.chipChanged : THEME.chipNormal, changed ? 0.94 : 0.88),
        border: emphasised ? rgba(THEME.white)
          : changed ? rgba(THEME.yellow) : rgba(laneColour(lane.direction), 0.8),
        text: changed ? rgba(THEME.yellow) : emphasised ? rgba(THEME.white) : "rgba(255, 255, 255, 0.92)",
        font: `${changed || emphasised ? "bold" : "600"} 11px ui-monospace, SFMono-Regular, Menlo, monospace`,
        fontSize: 11,
        paddingX: 4,
        paddingY: 2,
      };
      const { width, height } = this.chipMetrics(ctx, text, style);
      const fits = width <= box.width + 2 && height <= box.height + 2;
      if (fits || emphasised || (changed && allowChangedOverflow)) {
        this.drawChip(ctx, text, anchor, style);
        this.stats.speedLabels += 1;
      }
    }
  }

  drawPanel(ctx, lines, origin, alignRight = false, accent = null) {
    const font = "500 12px -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif";
    const mono = "500 12px ui-monospace, SFMono-Regular, Menlo, monospace";
    const widths = lines.map((line, index) => Math.ceil(this.measure(ctx, line.text, index === 1 && lines.length > 2 ? mono : font)));
    const contentWidth = Math.max(...widths, 0);
    const paddingX = 9;
    const paddingY = 7;
    const lineHeight = 15;
    const accentWidth = accent ? 3 : 0;
    const width = contentWidth + paddingX * 2 + accentWidth;
    const height = lines.length * lineHeight + (lines.length - 1) * 3 + paddingY * 2;
    const x = alignRight ? origin.x - width : origin.x;
    const y = origin.y;
    roundRectPath(ctx, x, y, width, height, 6);
    ctx.fillStyle = rgba(THEME.panel, 0.88);
    ctx.fill();
    ctx.strokeStyle = rgba(THEME.white, 0.22);
    ctx.lineWidth = 1;
    ctx.stroke();
    if (accent) {
      roundRectPath(ctx, x, y, accentWidth, height, 1.5);
      ctx.fillStyle = rgba(accent);
      ctx.fill();
    }
    lines.forEach((line, index) => {
      ctx.font = index === 0 ? "600 12.5px -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif"
        : index === 1 && lines.length > 2 ? mono : font;
      ctx.fillStyle = index === 0 ? rgba(THEME.white) : rgba(THEME.white, 0.8);
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      ctx.fillText(line.text, x + paddingX + accentWidth, y + paddingY + index * (lineHeight + 3));
    });
    return { x, y, width, height };
  }

  drawScaleBar(ctx) {
    const metres = niceStep(130 / this.scale);
    const width = metres * this.scale;
    if (!(width > 8) || width > this.width - 24) return;
    const origin = { x: 14, y: this.height - 26 };
    ctx.beginPath();
    ctx.moveTo(origin.x, origin.y);
    ctx.lineTo(origin.x + width, origin.y);
    ctx.moveTo(origin.x, origin.y - 4);
    ctx.lineTo(origin.x, origin.y + 4);
    ctx.moveTo(origin.x + width, origin.y - 4);
    ctx.lineTo(origin.x + width, origin.y + 4);
    ctx.strokeStyle = rgba(THEME.white, 0.85);
    ctx.lineWidth = 1.6;
    ctx.stroke();
    const label = metres >= 1000 ? `${(metres / 1000).toFixed(1)} km` : `${Math.round(metres)} m`;
    this.drawChip(ctx, label, { x: origin.x + width / 2, y: origin.y - 15 }, {
      background: "rgba(0, 0, 0, 0.6)", border: null, text: rgba(THEME.white),
      font: "500 10px -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif", fontSize: 10,
      paddingX: 4, paddingY: 1,
    });
  }

  drawCompass(ctx) {
    const centre = { x: this.width - 46, y: this.height - 48 };
    ctx.beginPath();
    ctx.moveTo(centre.x, centre.y - 15);
    ctx.lineTo(centre.x, centre.y + 15);
    ctx.moveTo(centre.x - 15, centre.y);
    ctx.lineTo(centre.x + 15, centre.y);
    ctx.strokeStyle = rgba(THEME.white, 0.5);
    ctx.lineWidth = 1;
    ctx.stroke();
    this.drawArrowhead(ctx, { x: centre.x, y: centre.y - 15 }, { x: 0, y: -1 }, 9, rgba(THEME.white, 0.8));
    this.drawArrowhead(ctx, { x: centre.x + 15, y: centre.y }, { x: 1, y: 0 }, 9, rgba(THEME.white, 0.8));
    ctx.font = "bold 10px -apple-system, BlinkMacSystemFont, sans-serif";
    ctx.fillStyle = rgba(THEME.white, 0.85);
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    ctx.fillText("Y", centre.x + 5, centre.y - 20);
    ctx.fillText("X", centre.x + 18, centre.y + 2);
    const north = this.document?.northAngle ?? null;
    if (north !== null) {
      const dx = Math.sin(north);
      const dy = -Math.cos(north);
      const tip = { x: centre.x + dx * 26, y: centre.y + dy * 26 };
      ctx.beginPath();
      ctx.moveTo(tip.x, tip.y);
      ctx.lineTo(centre.x, centre.y);
      ctx.strokeStyle = rgba(THEME.pink, 0.9);
      ctx.lineWidth = 1.6;
      ctx.stroke();
      this.drawArrowhead(ctx, tip, { x: dx, y: dy }, 9, THEME.pink);
      ctx.fillStyle = rgba(THEME.pink);
      ctx.fillText("N", centre.x + dx * 32 - 4, centre.y + dy * 32 - 5);
    } else {
      ctx.font = "500 9px -apple-system, BlinkMacSystemFont, sans-serif";
      ctx.fillStyle = rgba(THEME.white, 0.6);
      ctx.fillText("地图坐标", centre.x - 22, centre.y + 20);
    }
  }

  drawOverlays(ctx) {
    const document = this.document;
    const focusID = this.selectedID ?? this.hoverID;
    const lane = focusID === null ? null : document?.lanes.find((item) => item.id === focusID) ?? null;
    if (lane) {
      const current = this.effectiveSpeed(lane) ?? lane.originalSpeed;
      const lines = [{ text: `Lanelet ${lane.id} · ${directionTitle(lane.direction)}` }];
      if (current === null || current === undefined || current === "") lines.push({ text: "限速 未设置" });
      else if (lane.originalSpeed && lane.originalSpeed !== String(current)) {
        lines.push({ text: `限速 ${current} km/h（原 ${lane.originalSpeed}）` });
      } else lines.push({ text: `限速 ${current} km/h` });
      if (lane.boundsDisagree) lines.push({ text: "⚠ 左右边界方向不一致，行驶方向存疑" });
      else if (lane.handedness === Handedness.REVERSED) lines.push({ text: "反向层：实际行驶方向与存储顺序相反" });
      else if (lane.handedness === Handedness.UNKNOWN) lines.push({ text: "图层无法判定（车道形状退化）" });
      else lines.push({ text: "正向层：存储顺序就是行驶方向" });
      this.drawPanel(ctx, lines, { x: 12, y: 12 }, false, laneColour(lane.direction));
    }
    const visible = this.stats.lanesDrawn;
    const zoomLines = [
      { text: `放大 ${this.zoomMultiple.toFixed(1)}× · 视窗 ${this.visibleExtent.width.toFixed(0)} × ${this.visibleExtent.height.toFixed(0)} m` },
      { text: `视窗内 ${visible} 条 · 已修改 ${this.stats.changedInView} 条` },
    ];
    if (this.onlyChanged) zoomLines.push({ text: `只显示已修改车道 · ${this.layerFilter === LayerFilter.BOTH ? "两层同时显示" : this.layerFilter === LayerFilter.FORWARD ? "只看正向层" : "只看反向层"}` });
    else if (this.layerFilter !== LayerFilter.BOTH) zoomLines.push({ text: this.layerFilter === LayerFilter.FORWARD ? "只看正向层" : "只看反向层" });
    this.drawPanel(ctx, zoomLines, { x: this.width - 12, y: 12 }, true);
    this.drawScaleBar(ctx);
    this.drawCompass(ctx);
  }

  // MARK: - Interaction

  /** Topmost lanelet under a screen point, honouring the layer filter and any layer shift. */
  laneAt(point) {
    if (!this.document) return null;
    for (let index = this.document.lanes.length - 1; index >= 0; index -= 1) {
      const lane = this.document.lanes[index];
      if (lane.polygon.length < 4 || !lane.bounds) continue;
      if (this.onlyChanged && !this.changedIDs.has(lane.id)) continue;
      if (!layerMatches(this.layerFilter, lane.handedness)) continue;
      const box = this.screenBox(lane.bounds);
      if (point.x < box.minX - 3 || point.x > box.maxX + 3 || point.y < box.minY - 3 || point.y > box.maxY + 3) continue;
      if (polygonHits((worldPoint) => this.project(worldPoint), lane.polygon, this.shiftFor(lane), point)) return lane;
    }
    return null;
  }

  handleHover(point) {
    const lane = this.laneAt(point);
    const id = lane?.id ?? null;
    if (id === this.hoverID) return;
    this.hoverID = id;
    this.onHover(lane);
  }

  clearHover() {
    if (this.hoverID === null) return;
    this.hoverID = null;
    this.onHover(null);
  }
}

function polygonHits(project, polygon, shift, point) {
  let inside = false;
  let previous = polygon.length - 1;
  for (let current = 0; current < polygon.length; current += 1) {
    const a = project(polygon[current]);
    const b = project(polygon[previous]);
    const ax = a.x + shift.x;
    const ay = a.y + shift.y;
    const bx = b.x + shift.x;
    const by = b.y + shift.y;
    if ((ay > point.y) !== (by > point.y) && point.x < ((bx - ax) * (point.y - ay)) / (by - ay) + ax) {
      inside = !inside;
    }
    previous = current;
  }
  return inside;
}

function unionOf(lanes) {
  let box = null;
  for (const lane of lanes) {
    if (!lane.bounds) continue;
    if (!box) box = { ...lane.bounds };
    else {
      box.minX = Math.min(box.minX, lane.bounds.minX);
      box.minY = Math.min(box.minY, lane.bounds.minY);
      box.maxX = Math.max(box.maxX, lane.bounds.maxX);
      box.maxY = Math.max(box.maxY, lane.bounds.maxY);
    }
  }
  if (box) {
    box.width = box.maxX - box.minX;
    box.height = box.maxY - box.minY;
  }
  return box;
}

function medianOf(values) {
  if (values.length === 0) return 0;
  const sorted = values.slice().sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)];
}

// LaneSpeed web/desktop UI. Mirrors the verified native macOS app: same workflow, same wording,
// same safety rules (only speed_limit is ever written, the source file is never overwritten).

import {
  Handedness, LayerFilter, MapDocument, MapError, directionTitle, handednessTitle, normalizedSpeed,
} from "../../core/src/index.js";
import { MapView } from "./mapView.js";

const MAX_ROWS = 400; // the list is a view; keep the DOM light on 4500-lanelet maps

const el = (id) => document.getElementById(id);

const state = {
  document: null,
  fileName: null,
  fileHandle: null,
  edits: new Map(),
  savedEdits: new Map(),
  undo: [],
  selectedID: null,
  visible: [],
  busy: false,
  maximised: false,
};

const view = new MapView({
  onSelect: (lane) => selectLane(lane.id),
  onHover: (lane) => showHover(lane),
});

const canvas = el("mapCanvas");
const context = canvas.getContext("2d");
let devicePixelRatio = 1;

// ---------------------------------------------------------------------------------------------
// status, modal

function setStatus(text, isError = false) {
  el("status").textContent = text;
  el("status").parentElement.classList.toggle("error", isError);
}

function showModal(title, body, actions) {
  return new Promise((resolve) => {
    el("modalTitle").textContent = title;
    el("modalBody").textContent = body;
    const box = el("modalActions");
    box.textContent = "";
    actions.forEach((action, index) => {
      const button = document.createElement("button");
      button.className = `btn${action.primary ? " primary" : ""}`;
      button.type = "button";
      button.textContent = action.label;
      button.addEventListener("click", () => {
        el("modal").hidden = true;
        resolve(action.value ?? index);
      });
      box.appendChild(button);
    });
    el("modal").hidden = false;
  });
}

function showError(error) {
  const message = error instanceof MapError ? error.message : String(error?.message ?? error);
  setStatus(`操作未完成：${message}`, true);
  return showModal("操作未完成", message, [{ label: "知道了", value: 0, primary: true }]);
}

// ---------------------------------------------------------------------------------------------
// file access (desktop bridge, File System Access API, or a plain input/download fallback)

const OSM_TYPES = [{ description: "Lanelet2 OSM 地图", accept: { "application/xml": [".osm", ".xml"] } }];

async function openMap() {
  if (state.busy) return;
  try {
    if (globalThis.lanespeed?.openFile) {
      const opened = await globalThis.lanespeed.openFile();
      if (!opened) return;
      await load(opened.text, opened.name, null);
      return;
    }
    if (globalThis.showOpenFilePicker) {
      const [handle] = await globalThis.showOpenFilePicker({ types: OSM_TYPES, multiple: false });
      if (!handle) return;
      const file = await handle.getFile();
      await load(await file.text(), file.name, handle);
      return;
    }
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".osm,.xml,application/xml";
    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      if (file) await load(await file.text(), file.name, null);
    });
    input.click();
  } catch (error) {
    if (error?.name !== "AbortError") await showError(error);
  }
}

async function load(text, name, handle) {
  if (state.busy) return;
  // Parse first: a broken file must never cost the user the map and edits they already have.
  let document;
  try {
    document = new MapDocument(text);
  } catch (error) {
    await showError(error);
    setStatus("导入失败；请查看错误说明。当前地图与未导出的修改都保持原样。", true);
    return;
  }
  if (state.document && state.edits.size > 0 && !sameEdits(state.edits, state.savedEdits)) {
    const answer = await showModal("还有未导出的限速修改",
      "继续打开新地图将丢弃未导出的修改。要保留它们，请先取消并点击「导出副本」。原地图文件不受影响。",
      [{ label: "取消", value: 0 }, { label: "放弃修改并继续", value: 1, primary: true }]);
    if (answer !== 1) return;
  }
  state.busy = true;
  setStatus(`正在读取 ${name}…`);
  state.document = document;
  state.fileName = name;
  state.fileHandle = handle;
  state.edits = new Map();
  state.savedEdits = new Map();
  state.undo = [];
  state.selectedID = null;
  el("includeUnmarked").checked = false;
  el("category").value = "all";
  el("search").value = "";
  el("layerPopup").value = "both";
  el("separateLayers").checked = false;
  el("layerOnly").checked = false;
  view.setLayerFilter(LayerFilter.BOTH);
  view.separateLayers = false;
  view.onlyChanged = false;
  view.changedIDs = new Set();
  view.setDocument(document);
  el("filename").textContent = name;
  el("summary").textContent = `${document.lanes.length} 条 Lanelet · ${document.nodeCount} 个节点 · ${document.drawableCount} 条可预览`;
  el("coordinateLabel").textContent = document.coordinateDescription
    + (document.northAngle === null ? "\n地图未包含经纬度，方向以地图自身 X / Y 轴为准" : "\n已按经纬度标出正北方向")
    + (document.directionConflictCount > 0 ? `\n⚠ ${document.directionConflictCount} 条车道左右边界方向不一致（粉色描边）` : "");
  setStatus(`导入成功：${name}${document.drawableCount < document.lanes.length ? `（${document.lanes.length - document.drawableCount} 条缺少完整边界，仅列表可编辑）` : ""}`);
  document.title = `${name} — LaneSpeed 限速编辑器`;
  state.busy = false;
  refresh();
  resizeCanvas();
}

async function exportMap() {
  if (!state.document || state.busy) return;
  try {
    const output = state.document.export(state.edits);
    const suggested = suggestName(state.fileName);
    if (globalThis.lanespeed?.saveFile) {
      const path = await globalThis.lanespeed.saveFile(suggested, output);
      if (!path) return;
      state.savedEdits = new Map(state.edits);
      refresh();
      setStatus(`导出成功：${path} · 修改 ${state.edits.size} 条 · 原图未改动`);
      await showModal("地图副本已导出", `${path}\n\n修改 ${state.edits.size} 条车道。请在 Autoware 中验证后再用于车辆。`, [{ label: "完成", value: 0, primary: true }]);
      return;
    }
    if (globalThis.showSaveFilePicker) {
      const handle = await globalThis.showSaveFilePicker({ suggestedName: suggested, types: [{ description: "Lanelet2 OSM 地图", accept: { "application/xml": [".osm"] } }] });
      const writable = await handle.createWritable();
      await writable.write(output);
      await writable.close();
    } else {
      const blob = new Blob([output], { type: "application/xml;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = suggested;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    }
    state.savedEdits = new Map(state.edits);
    refresh();
    setStatus(`导出成功：${suggested} · 修改 ${state.edits.size} 条 · 原图未改动`);
    await showModal("地图副本已导出", `${suggested}\n\n修改 ${state.edits.size} 条车道。请在 Autoware 中验证后再用于车辆。`, [{ label: "完成", value: 0, primary: true }]);
  } catch (error) {
    if (error?.name === "AbortError") return;
    await showError(error);
    setStatus(`导出失败：${error.message}`, true);
  }
}

function suggestName(name) {
  const base = (name ?? "lanelet2_map.osm").replace(/\.(osm|xml)$/i, "");
  return `${base}_限速修改.osm`;
}

// ---------------------------------------------------------------------------------------------
// editing

function refresh() {
  const hasDocument = state.document !== null;
  el("openButton").disabled = state.busy;
  el("exportButton").disabled = !hasDocument || state.busy;
  el("undoButton").disabled = state.undo.length === 0 || state.busy;
  for (const direction of ["straight", "left", "right"]) {
    const count = state.document?.lanes.filter((lane) => lane.direction === direction).length ?? 0;
    const title = direction.charAt(0).toUpperCase() + direction.slice(1);
    el(`count${title}`).textContent = `${count} 条`;
    el(`speed${title}`).disabled = !hasDocument || state.busy;
    document.querySelector(`[data-apply="${direction}"]`).disabled = !hasDocument || state.busy;
  }
  el("includeUnmarked").disabled = !hasDocument || state.busy;
  const missing = state.document?.lanes.filter((lane) => !lane.originalDirection?.trim()).length ?? 0;
  const other = (state.document?.lanes.filter((lane) => lane.direction === "unmarked").length ?? 0) - missing;
  el("unmarkedLabel").textContent = `未标注：${missing} 条${other > 0 ? ` · 其他属性：${other} 条` : ""}`;
  el("changedLabel").textContent = `已修改 ${state.edits.size} 条车道${state.edits.size > 0 && sameEdits(state.edits, state.savedEdits) ? " · 已导出" : ""}`;
  el("layerPopup").disabled = !hasDocument || state.busy;
  el("separateLayers").disabled = !hasDocument || state.busy;
  el("layerOnly").disabled = !hasDocument || state.busy || view.layerFilter === LayerFilter.BOTH;
  if (view.layerFilter === LayerFilter.BOTH) el("layerOnly").checked = false;
  for (const [id, prop] of [["toggleSpeed", "showSpeed"], ["toggleDirection", "showDirection"], ["toggleFill", "showFill"], ["toggleGrid", "showGrid"], ["toggleOnlyChanged", "onlyChanged"]]) {
    el(id).checked = view[prop];
    el(id).disabled = !hasDocument || state.busy || (id === "toggleOnlyChanged" && state.edits.size === 0);
  }
  el("reviewButton").disabled = !hasDocument || state.busy || state.edits.size === 0;
  el("reviewNextButton").disabled = !hasDocument || state.busy || state.edits.size === 0;
  el("layerDataButton").disabled = !hasDocument || state.busy || (state.document?.reverseLayer.length ?? 0) === 0;
  if (!hasDocument) el("layerSummary").textContent = "打开地图后显示方向分层统计";
  else refreshLayerSummary();
  view.changedIDs = new Set(state.edits.keys());
  view.effectiveSpeed = (lane) => state.edits.get(lane.id) ?? lane.originalSpeed;
  refreshTable();
  refreshSelection();
}

function sameEdits(a, b) {
  if (a.size !== b.size) return false;
  for (const [key, value] of a) if (b.get(key) !== value) return false;
  return true;
}

function refreshLayerSummary() {
  const document = state.document;
  if (!document) return;
  const forward = document.statistics(Handedness.FORWARD);
  const reverse = document.statistics(Handedness.REVERSED);
  const unknown = document.statistics(Handedness.UNKNOWN);
  const lines = [`正向 ${forward.count} 条 · ${Math.round(forward.length)} m`, `反向 ${reverse.count} 条 · ${Math.round(reverse.length)} m`];
  if (unknown.count > 0) lines.push(`无法判定 ${unknown.count} 条`);
  if (reverse.count > 0) {
    const pairs = document.reverseLayerPairs();
    const matched = pairs.filter((pair) => pair.forward !== null && pair.overlap >= 0.5).length;
    lines.push(`反向层中与正向层重合：${matched} / ${pairs.length} 条`);
  }
  el("layerSummary").textContent = lines.join("\n");
}

function batchTargets(direction) {
  const document = state.document;
  if (!document) return [];
  const layerOnly = el("layerOnly").checked && view.layerFilter !== LayerFilter.BOTH;
  return document.lanes.filter((lane) => {
    if (layerOnly && view.layerFilter === LayerFilter.FORWARD && lane.handedness !== Handedness.FORWARD) return false;
    if (layerOnly && view.layerFilter === LayerFilter.REVERSED && lane.handedness !== Handedness.REVERSED) return false;
    if (lane.direction === direction) return true;
    return direction === "straight" && el("includeUnmarked").checked && !lane.originalDirection?.trim();
  });
}

async function applyDirection(direction) {
  if (!state.document || state.busy) return;
  try {
    const input = el(`speed${direction.charAt(0).toUpperCase()}${direction.slice(1)}`);
    const speed = normalizedSpeed(input.value);
    const targets = batchTargets(direction);
    if (targets.length === 0) {
      await showError(new MapError(el("layerOnly").checked
        ? `当前图层里没有符合条件的${directionTitle(direction)}车道。可把「批量改速只作用于当前图层」关掉，或换一个图层。`
        : `没有符合条件的${directionTitle(direction)}车道。若地图未标注 turn_direction，请确认后勾选「将未标注车道一起按直行改速」。`));
      return;
    }
    if (direction === "straight" && el("includeUnmarked").checked) {
      const unmarked = targets.filter((lane) => lane.direction === "unmarked").length;
      if (unmarked > 0) {
        const answer = await showModal("同时修改未标注车道？",
          `这些车道没有 turn_direction 属性，不能据此确定是否直行。确认后，本次共 ${targets.length} 条车道将设为 ${speed} km/h；转向属性保持不变。`,
          [{ label: "取消", value: 0 }, { label: "确认改速", value: 1, primary: true }]);
        if (answer !== 1) return;
      }
    }
    commit(targets.map((lane) => lane.id), speed);
  } catch (error) {
    await showError(error);
  }
}

function applySingle() {
  if (!state.selectedID || state.busy) return;
  try {
    commit([state.selectedID], normalizedSpeed(el("selectedSpeed").value));
  } catch (error) {
    showError(error);
  }
}

function commit(ids, speed) {
  const document = state.document;
  if (!document) return;
  const targets = new Set(ids);
  const next = new Map(state.edits);
  for (const lane of document.lanes) {
    if (!targets.has(lane.id)) continue;
    if (lane.originalSpeed === speed) next.delete(lane.id);
    else next.set(lane.id, speed);
  }
  if (sameEdits(next, state.edits)) {
    setStatus(`选中的车道已经是 ${speed} km/h，无需修改。`);
    return;
  }
  state.undo.push(new Map(state.edits));
  if (state.undo.length > 100) state.undo.shift();
  state.edits = next;
  refresh();
  const scope = el("layerOnly").checked && view.layerFilter !== LayerFilter.BOTH
    ? `（${view.layerFilter === LayerFilter.FORWARD ? "只看正向层" : "只看反向层"}）` : "";
  setStatus(`已将${scope} ${ids.length} 条车道设为 ${speed} km/h。点击「导出副本」保存，原图未改动。`);
}

function undoChange() {
  if (state.busy || state.undo.length === 0) return;
  state.edits = state.undo.pop();
  refresh();
  setStatus("已撤销上次改速。原图未改动。");
}

// ---------------------------------------------------------------------------------------------
// selection, list and review

function visibleLanes() {
  const document = state.document;
  if (!document) return [];
  const query = el("search").value.trim().toLowerCase();
  const filter = el("category").value;
  return document.lanes.filter((lane) => {
    if (query && !lane.id.toLowerCase().includes(query)) return false;
    if (filter === "changed") return state.edits.has(lane.id);
    if (filter === "forward") return lane.handedness === Handedness.FORWARD;
    if (filter === "reversed") return lane.handedness === Handedness.REVERSED;
    if (filter !== "all") return lane.direction === filter;
    return true;
  });
}

function refreshTable() {
  const body = el("laneBody");
  state.visible = visibleLanes();
  body.textContent = "";
  const rows = state.visible.slice(0, MAX_ROWS);
  const fragment = document.createDocumentFragment();
  for (const lane of rows) {
    const tr = document.createElement("tr");
    tr.dataset.id = lane.id;
    if (lane.id === state.selectedID) tr.classList.add("selected");
    const current = state.edits.get(lane.id) ?? lane.originalSpeed;
    const changed = state.edits.has(lane.id);
    const cells = [
      ["id", lane.id, ""],
      ["layer", handednessTitle(lane.handedness), lane.handedness === Handedness.REVERSED ? "reversed" : "forward"],
      ["", lane.direction === "unmarked" && lane.originalDirection ? `其他：${lane.originalDirection}` : directionTitle(lane.direction), ""],
      ["num", lane.originalSpeed ?? "未设置", ""],
      ["num", current ?? "未设置", changed ? "changed" : ""],
      ["", changed ? "已修改" : "—", ""],
    ];
    for (const [cls, text, extra] of cells) {
      const td = document.createElement("td");
      td.textContent = text;
      if (cls) td.className = cls;
      if (extra) td.classList.add(extra);
      tr.appendChild(td);
    }
    tr.addEventListener("click", () => selectLane(lane.id, { scroll: false }));
    tr.addEventListener("dblclick", () => {
      selectLane(lane.id, { scroll: false });
      view.focusLane(lane);
      redraw();
    });
    fragment.appendChild(tr);
  }
  body.appendChild(fragment);
  el("tableCount").textContent = state.visible.length > rows.length
    ? `${rows.length} / ${state.visible.length} 条` : `${state.visible.length} 条`;
}

function selectLane(id, options = {}) {
  state.selectedID = id;
  const lane = state.document?.lanes.find((item) => item.id === id) ?? null;
  if (lane && !state.visible.some((item) => item.id === id)) {
    el("category").value = "all";
    el("search").value = "";
    refreshTable();
  }
  for (const tr of el("laneBody").children) tr.classList.toggle("selected", tr.dataset.id === id);
  if (options.scroll !== false) {
    const row = [...el("laneBody").children].find((tr) => tr.dataset.id === id);
    row?.scrollIntoView({ block: "nearest" });
  }
  view.selectedID = id;
  refreshSelection();
  redraw();
}

function refreshSelection() {
  const lane = state.document?.lanes.find((item) => item.id === state.selectedID) ?? null;
  const hasLane = lane !== null;
  el("applySingle").disabled = !hasLane || state.busy;
  el("selectedSpeed").disabled = !hasLane || state.busy;
  el("focusSelected").disabled = !hasLane || lane.polygon.length === 0 || state.busy;
  if (!lane) {
    el("selectedLabel").textContent = "在地图或列表中选择一条车道";
    el("selectedSpeed").value = "";
    return;
  }
  el("selectedLabel").textContent = `ID ${lane.id} · ${directionTitle(lane.direction)} · ${handednessTitle(lane.handedness)}层\n原限速：${lane.originalSpeed ?? "未设置"} km/h`;
  if (document.activeElement !== el("selectedSpeed")) {
    el("selectedSpeed").value = state.edits.get(lane.id) ?? lane.originalSpeed ?? "";
  }
}

function showHover(lane) {
  if (!lane) {
    el("hoverLabel").textContent = "把鼠标移到车道上可查看该车道的限速与方向";
    return;
  }
  const current = state.edits.get(lane.id) ?? lane.originalSpeed ?? "未设置";
  let text = `Lanelet ${lane.id} · ${directionTitle(lane.direction)} · ${handednessTitle(lane.handedness)}层 · 限速 ${current} km/h`;
  if (state.edits.has(lane.id) && lane.originalSpeed) text += `（原 ${lane.originalSpeed}）`;
  if (lane.boundsDisagree) text += " · ⚠ 左右边界方向不一致";
  el("hoverLabel").textContent = text;
}

async function reviewChanges() {
  if (!state.document || state.busy) return;
  const changed = state.document.lanes.filter((lane) => state.edits.has(lane.id));
  if (changed.length === 0) {
    await showError(new MapError("还没有任何限速修改。先填写速度并点击「应用」。"));
    return;
  }
  view.onlyChanged = true;
  el("toggleOnlyChanged").checked = true;
  const readable = view.review(changed);
  const inView = view.lanesInView(changed).length;
  redraw();
  refresh();
  setStatus(readable
    ? `已只显示 ${changed.length} 条已修改车道，黄色数字就是修改后的限速（当前视野内 ${inView} 条）。`
    : `已只显示 ${changed.length} 条已修改车道（当前视野内 ${inView} 条）；缩小状态下数值放不下，请继续放大，或用「逐条核对」逐条查看。`);
}

function reviewNext() {
  const document = state.document;
  if (!document || state.busy) return;
  const changed = document.lanes.filter((lane) => state.edits.has(lane.id));
  if (changed.length === 0) {
    showError(new MapError("还没有任何限速修改，没有可以逐条核对的车道。"));
    return;
  }
  const ids = changed.map((lane) => lane.id);
  const currentIndex = ids.indexOf(state.selectedID);
  const next = (currentIndex + 1) % ids.length;
  const lane = changed[next];
  selectLane(lane.id);
  view.focusLane(lane);
  redraw();
  setStatus(`第 ${next + 1} / ${ids.length} 条已修改车道：Lanelet ${lane.id} · ${directionTitle(lane.direction)} · `
    + `${state.edits.get(lane.id) ?? lane.originalSpeed ?? "未设置"} km/h（原 ${lane.originalSpeed ?? "未设置"}）。再点「逐条核对」看下一条。`);
}

// ---------------------------------------------------------------------------------------------
// direction layer data

async function showLayerData() {
  const document = state.document;
  if (!document || state.busy) return;
  const reverse = document.statistics(Handedness.REVERSED);
  if (reverse.count === 0) {
    await showError(new MapError("这份地图里没有反向层车道（没有左右边界与行驶方向对调的车道）。"));
    return;
  }
  const forward = document.statistics(Handedness.FORWARD);
  const pairs = document.reverseLayerPairs();
  const matched = pairs.filter((pair) => pair.forward !== null && pair.overlap >= 0.5);
  const distribution = (counts) => Object.entries(counts)
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([key, value]) => `${key}: ${value} 条`).join("，");
  const average = matched.length > 0 ? matched.reduce((sum, pair) => sum + pair.overlap, 0) / matched.length : 0;
  const text = `反向层 ${reverse.count} 条车道，总长 ${Math.round(reverse.length)} m（正向层 ${forward.count} 条 / ${Math.round(forward.length)} m）

限速分布：${distribution(reverse.speeds)}
转向分布：${distribution(reverse.turns)}
左右边界方向冲突：${reverse.conflicts} 条
与正向层几何重合：${matched.length} / ${pairs.length} 条，平均重合度 ${Math.round(average * 100)}%

反向层的实际行驶方向与地图里存储的点序相反；导出 CSV 可以查看每条车道的地图 ID、存储航向、实际航向、限速、长度和对应的正向车道。`;
  const answer = await showModal("方向分层数据 · 反向层", text, [
    { label: "关闭", value: 0 },
    { label: "导出 CSV…", value: 1, primary: true },
  ]);
  if (answer === 1) await exportLayerCSV();
}

/** One row per lanelet: layer, stored vs real travel direction, speeds, length and pairing. */
export function layerCSV(document, edits = new Map()) {
  if (!document) return null;
  const pairs = new Map();
  for (const pair of document.reverseLayerPairs()) {
    if (pair.forward) pairs.set(pair.reversed.id, { id: pair.forward.id, overlap: pair.overlap });
  }
  let csv = "lanelet_id,layer,stored_heading_deg,actual_heading_deg,stored_speed_kmh,current_speed_kmh,length_m,twin_forward_id,twin_overlap,bounds_conflict\n";
  for (const lane of document.lanes) {
    const stored = headingOf(lane.centerline);
    const actual = lane.handedness === Handedness.REVERSED ? stored + 180 : stored;
    const twin = pairs.get(lane.id);
    const fields = [
      lane.id, handednessTitle(lane.handedness), stored.toFixed(1), actual.toFixed(1),
      lane.originalSpeed ?? "", edits.get(lane.id) ?? lane.originalSpeed ?? "",
      lane.centerlineLength.toFixed(2), twin?.id ?? "", twin ? twin.overlap.toFixed(2) : "",
      lane.boundsDisagree ? "yes" : "no",
    ];
    csv += `${fields.map((field) => (String(field).includes(",") ? `"${field}"` : field)).join(",")}\n`;
  }
  return csv;
}

function headingOf(points) {
  if (points.length < 2) return 0;
  const first = points[0];
  const last = points[points.length - 1];
  return (Math.atan2(last.y - first.y, last.x - first.x) * 180) / Math.PI;
}

export async function exportLayerCSV() {
  const csv = layerCSV(state.document, state.edits);
  if (!csv) return;
  const name = (state.fileName ?? "lanelet2_map.osm").replace(/\.(osm|xml)$/i, "") + "_方向分层.csv";
  try {
    if (globalThis.lanespeed?.saveFile) {
      const path = await globalThis.lanespeed.saveFile(name, csv);
      if (path) setStatus(`已导出方向分层数据：${path}（${state.document.lanes.length} 条车道，地图未改动）`);
      return;
    }
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    setStatus(`已导出方向分层数据：${name}（${state.document.lanes.length} 条车道，地图未改动）`);
  } catch (error) {
    if (error?.name !== "AbortError") await showError(error);
  }
}

// ---------------------------------------------------------------------------------------------
// canvas plumbing

function resizeCanvas() {
  const wrap = el("canvasWrap");
  const rect = wrap.getBoundingClientRect();
  const width = Math.max(1, Math.floor(rect.width));
  const height = Math.max(1, Math.floor(rect.height));
  devicePixelRatio = globalThis.devicePixelRatio || 1;
  canvas.width = Math.round(width * devicePixelRatio);
  canvas.height = Math.round(height * devicePixelRatio);
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;
  view.setSize(width, height);
  redraw();
}

function redraw() {
  context.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
  return view.render(context);
}

// ---------------------------------------------------------------------------------------------
// interaction

function canvasPoint(event) {
  const rect = canvas.getBoundingClientRect();
  return { x: event.clientX - rect.left, y: event.clientY - rect.top };
}

function bindCanvas() {
  let dragging = false;
  let moved = false;
  let last = { x: 0, y: 0 };

  canvas.addEventListener("mousedown", (event) => {
    dragging = true;
    moved = false;
    last = canvasPoint(event);
    canvas.style.cursor = "grabbing";
  });
  globalThis.addEventListener("mouseup", (event) => {
    if (!dragging) return;
    dragging = false;
    canvas.style.cursor = "crosshair";
    if (moved) return;
    const point = canvasPoint(event);
    if (point.x < 0 || point.y < 0 || point.x > view.width || point.y > view.height) return;
    const lane = view.laneAt(point);
    if (lane) selectLane(lane.id);
  });
  canvas.addEventListener("mousemove", (event) => {
    const point = canvasPoint(event);
    if (dragging) {
      const dx = point.x - last.x;
      const dy = point.y - last.y;
      if (Math.abs(dx) > 1 || Math.abs(dy) > 1) moved = true;
      view.offsetX += dx;
      view.offsetY -= dy;
      view.framing = null;
      last = point;
      redraw();
      return;
    }
    const before = view.hoverID;
    view.handleHover(point);
    if (view.hoverID !== before) redraw();
  });
  canvas.addEventListener("mouseleave", () => {
    view.clearHover();
    redraw();
  });
  canvas.addEventListener("wheel", (event) => {
    event.preventDefault();
    const factor = Math.exp(-event.deltaY * (event.deltaMode === 0 ? 0.0016 : 0.06));
    view.zoomBy(factor, canvasPoint(event));
    redraw();
  }, { passive: false });

  const wrap = el("canvasWrap");
  for (const [name, active] of [["dragenter", true], ["dragover", true], ["dragleave", false], ["drop", false]]) {
    wrap.addEventListener(name, (event) => {
      event.preventDefault();
      el("dropzone").classList.toggle("active", active);
      if (name !== "drop") return;
      const file = event.dataTransfer?.files?.[0];
      if (file) file.text().then((text) => load(text, file.name, null));
    });
  }
}

// ---------------------------------------------------------------------------------------------
// wiring

function bindControls() {
  el("openButton").addEventListener("click", openMap);
  el("exportButton").addEventListener("click", exportMap);
  el("undoButton").addEventListener("click", undoChange);
  for (const direction of ["straight", "left", "right"]) {
    document.querySelector(`[data-apply="${direction}"]`).addEventListener("click", () => applyDirection(direction));
  }
  el("applySingle").addEventListener("click", applySingle);
  el("focusSelected").addEventListener("click", () => {
    const lane = state.document?.lanes.find((item) => item.id === state.selectedID);
    if (lane) {
      view.focusLane(lane);
      redraw();
    }
  });
  el("includeUnmarked").addEventListener("change", refresh);
  el("category").addEventListener("change", refreshTable);
  el("search").addEventListener("input", refreshTable);
  el("layerDataButton").addEventListener("click", showLayerData);
  el("reviewButton").addEventListener("click", reviewChanges);
  el("reviewNextButton").addEventListener("click", reviewNext);
  el("layerPopup").addEventListener("change", () => {
    view.layerFilter = el("layerPopup").value;
    refresh();
    redraw();
  });
  el("separateLayers").addEventListener("change", () => {
    view.separateLayers = el("separateLayers").checked;
    redraw();
  });
  el("layerOnly").addEventListener("change", () => {
    setStatus(el("layerOnly").checked
      ? `批量改速将只作用于${el("layerPopup").selectedOptions[0].textContent}。`
      : "批量改速作用于全部车道。");
  });
  for (const [id, prop] of [["toggleSpeed", "showSpeed"], ["toggleDirection", "showDirection"], ["toggleFill", "showFill"], ["toggleGrid", "showGrid"], ["toggleOnlyChanged", "onlyChanged"]]) {
    el(id).addEventListener("change", () => {
      view[prop] = el(id).checked;
      redraw();
    });
  }
  el("fitButton").addEventListener("click", () => {
    view.fit();
    redraw();
    setStatus("已显示全部车道，并放大到铺满窗口；需要更大时点「地图最大化」。");
  });
  el("zoomInButton").addEventListener("click", () => {
    view.zoomAroundCentre(1.35);
    redraw();
  });
  el("zoomOutButton").addEventListener("click", () => {
    view.zoomAroundCentre(1 / 1.35);
    redraw();
  });
  el("maxButton").addEventListener("click", () => {
    state.maximised = !state.maximised;
    document.getElementById("app").classList.toggle("mapless", state.maximised);
    el("maxButton").textContent = state.maximised ? "恢复列表" : "地图最大化";
    requestAnimationFrame(() => {
      resizeCanvas();
      view.fit();
      redraw();
      setStatus(state.maximised ? "地图已最大化；点「显示全部」可让车道铺满整个窗口。" : "已恢复侧栏与车道列表。");
    });
  });

  globalThis.addEventListener("keydown", (event) => {
    const meta = event.metaKey || event.ctrlKey;
    if (!meta) return;
    const key = event.key.toLowerCase();
    if (key === "o") { event.preventDefault(); openMap(); }
    else if (key === "s") { event.preventDefault(); exportMap(); }
    else if (key === "z") { event.preventDefault(); undoChange(); }
    else if (key === "0") { event.preventDefault(); el("fitButton").click(); }
    else if (key === "=" || key === "+") { event.preventDefault(); el("zoomInButton").click(); }
    else if (key === "-") { event.preventDefault(); el("zoomOutButton").click(); }
    else if (key === "r") { event.preventDefault(); if (event.shiftKey) reviewNext(); else reviewChanges(); }
    else if (key === "m" && event.shiftKey) { event.preventDefault(); el("maxButton").click(); }
  });

  globalThis.addEventListener("resize", resizeCanvas);
  if (globalThis.ResizeObserver) new ResizeObserver(resizeCanvas).observe(el("canvasWrap"));
}

bindControls();
bindCanvas();
refresh();
resizeCanvas();

// small surface used by the desktop shell and by tests
globalThis.lanespeedApp = { state, view, load, refresh, selectLane, commit, exportLayerCSV, layerCSV, redraw };

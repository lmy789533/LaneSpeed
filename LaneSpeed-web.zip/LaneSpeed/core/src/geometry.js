// Pure geometry, ported one to one from the verified Swift implementation so the two versions
// classify and label lanelets identically.

export const Handedness = Object.freeze({ FORWARD: "forward", REVERSED: "reversed", UNKNOWN: "unknown" });

export function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

/** Re-samples a polyline into `count` points spaced evenly along its length. */
export function resample(points, count) {
  if (points.length < 2 || count < 2) return points.slice();
  const lengths = [0];
  for (let index = 1; index < points.length; index += 1) {
    lengths.push(lengths[index - 1] + distance(points[index - 1], points[index]));
  }
  const total = lengths[lengths.length - 1];
  if (!(total > 0)) return new Array(count).fill(points[0]);
  const result = new Array(count);
  let segment = 1;
  for (let index = 0; index < count; index += 1) {
    const target = (total * index) / (count - 1);
    while (segment < points.length - 1 && lengths[segment] < target) segment += 1;
    const span = lengths[segment] - lengths[segment - 1];
    const ratio = span > 0 ? (target - lengths[segment - 1]) / span : 0;
    const a = points[segment - 1];
    const b = points[segment];
    result[index] = { x: a.x + (b.x - a.x) * ratio, y: a.y + (b.y - a.y) * ratio };
  }
  return result;
}

export function lengthOf(points) {
  let total = 0;
  for (let index = 1; index < points.length; index += 1) total += distance(points[index - 1], points[index]);
  return total;
}

/** Centre line of a lanelet. `left` defines the direction; `right` must already match it. */
export function centerline(left, right, samples = 16) {
  if (left.length === 0) return right.slice();
  if (right.length === 0) return left.slice();
  const a = resample(left, samples);
  const b = resample(right, samples);
  return a.map((point, index) => ({ x: (point.x + b[index].x) / 2, y: (point.y + b[index].y) / 2 }));
}

/** Signed area of a closed ring (shoelace formula). */
export function area(polygon) {
  if (polygon.length < 3) return 0;
  let total = 0;
  let previous = polygon.length - 1;
  for (let current = 0; current < polygon.length; current += 1) {
    total += polygon[previous].x * polygon[current].y - polygon[current].x * polygon[previous].y;
    previous = current;
  }
  return total / 2;
}

export function centroid(polygon) {
  if (polygon.length === 0) return { x: 0, y: 0 };
  let x = 0;
  let y = 0;
  for (const point of polygon) {
    x += point.x;
    y += point.y;
  }
  return { x: x / polygon.length, y: y / polygon.length };
}

/** Ray casting point-in-polygon test for a closed ring. */
export function polygonContains(polygon, point) {
  if (polygon.length < 3) return false;
  let result = false;
  let previous = polygon.length - 1;
  for (let current = 0; current < polygon.length; current += 1) {
    const a = polygon[current];
    const b = polygon[previous];
    if ((a.y > point.y) !== (b.y > point.y)
      && point.x < ((b.x - a.x) * (point.y - a.y)) / (b.y - a.y) + a.x) {
      result = !result;
    }
    previous = current;
  }
  return result;
}

/**
 * Most central point of a lanelet, used as the anchor for speed and direction labels. Only
 * candidates that really fall inside the polygon are accepted, so a label never spills over a
 * neighbouring lanelet.
 */
export function labelPoint(centerlinePoints, polygon) {
  if (centerlinePoints.length === 0) return null;
  if (centerlinePoints.length < 2 || polygon.length < 3) {
    return centerlinePoints[Math.floor(centerlinePoints.length / 2)];
  }
  const candidates = centerlinePoints.concat([centroid(polygon)]);
  let inside = null;
  let insideClearance = -1;
  let fallback = centerlinePoints[Math.floor(centerlinePoints.length / 2)];
  let fallbackClearance = -1;
  for (const candidate of candidates) {
    let nearest = Infinity;
    for (const point of polygon) {
      const d = distance(point, candidate);
      if (d < nearest) nearest = d;
    }
    if (nearest > fallbackClearance) {
      fallbackClearance = nearest;
      fallback = candidate;
    }
    if (nearest > insideClearance && polygonContains(polygon, candidate)) {
      insideClearance = nearest;
      inside = candidate;
    }
  }
  return inside ?? fallback;
}

/** Average width of a lanelet: area over centre-line length, correct for slanted lanelets. */
export function averageWidth(polygon, centerlinePoints, fallback) {
  const length = lengthOf(centerlinePoints);
  if (!(length > 0.001) || polygon.length < 3) return fallback;
  return Math.abs(area(polygon)) / length;
}

/**
 * Forward / reverse layer test. The ring `left + reversed(right)` is clockwise when the left
 * bound really is on the left of travel, so the sign of its area decides. Judging by the whole
 * polygon instead of one sample point keeps curved and irregular lanelets correct.
 */
export function handedness(polygon, bounds) {
  if (polygon.length < 3 || !(bounds.width > 0) || !(bounds.height > 0)) return Handedness.UNKNOWN;
  const signed = area(polygon);
  if (Math.abs(signed) <= 0.05 * bounds.width * bounds.height) return Handedness.UNKNOWN;
  return signed < 0 ? Handedness.FORWARD : Handedness.REVERSED;
}

/** 1 / 2 / 5 x 10^n, the smallest value at or above `raw`. Keeps grids and scale bars round. */
export function niceStep(raw) {
  if (!Number.isFinite(raw) || raw <= 0) return 1;
  const exponent = Math.floor(Math.log10(raw));
  const base = 10 ** exponent;
  const normalised = raw / base;
  const step = normalised <= 1 ? 1 : normalised <= 2 ? 2 : normalised <= 5 ? 5 : 10;
  return step * base;
}

/** Point and tangent at `distance` along a polyline. */
export function pointOn(points, distanceAlong) {
  if (points.length < 2) return null;
  let travelled = 0;
  for (let index = 1; index < points.length; index += 1) {
    const a = points[index - 1];
    const b = points[index];
    const segment = Math.hypot(b.x - a.x, b.y - a.y);
    if (segment <= 0) continue;
    if (travelled + segment >= distanceAlong) {
      const t = (distanceAlong - travelled) / segment;
      return {
        point: { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t },
        direction: { x: b.x - a.x, y: b.y - a.y },
      };
    }
    travelled += segment;
  }
  const a = points[points.length - 2];
  const b = points[points.length - 1];
  return { point: b, direction: { x: b.x - a.x, y: b.y - a.y } };
}

export function boundsOf(points) {
  if (points.length === 0) return null;
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const point of points) {
    if (point.x < minX) minX = point.x;
    if (point.y < minY) minY = point.y;
    if (point.x > maxX) maxX = point.x;
    if (point.y > maxY) maxY = point.y;
  }
  return { minX, minY, maxX, maxY, width: maxX - minX, height: maxY - minY };
}

export function unionBounds(a, b) {
  if (!a) return b;
  if (!b) return a;
  return {
    minX: Math.min(a.minX, b.minX),
    minY: Math.min(a.minY, b.minY),
    maxX: Math.max(a.maxX, b.maxX),
    maxY: Math.max(a.maxY, b.maxY),
    width: Math.max(a.maxX, b.maxX) - Math.min(a.minX, b.minX),
    height: Math.max(a.maxY, b.maxY) - Math.min(a.minY, b.minY),
  };
}

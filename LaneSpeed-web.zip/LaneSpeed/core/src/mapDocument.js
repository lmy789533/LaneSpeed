// The map model: parsing, lanelet geometry, direction layers and the byte-exact exporter.
// Ported one to one from native-macos/Sources/MapCore.swift so both versions behave identically.

import {
  MapError, PATCHER_ATTRIBUTES, PARSER_ATTRIBUTES, containsDoctypeOrEntity, lineAt, scanXml,
} from "./xml.js";
import {
  Handedness, averageWidth, area, boundsOf, centerline, centroid, handedness, labelPoint,
  lengthOf, polygonContains, resample, unionBounds,
} from "./geometry.js";

export const Direction = Object.freeze(["straight", "left", "right", "unmarked"]);

export function directionOf(tag) {
  const value = String(tag ?? "").trim().toLowerCase();
  if (value === "straight" || value === "left" || value === "right") return value;
  return "unmarked";
}

export function directionTitle(direction) {
  switch (direction) {
    case "straight": return "直行";
    case "left": return "左转";
    case "right": return "右转";
    default: return "未标注 / 其他";
  }
}

export function handednessTitle(handedness) {
  switch (handedness) {
    case Handedness.FORWARD: return "正向";
    case Handedness.REVERSED: return "反向";
    default: return "无法判定";
  }
}

export const LayerFilter = Object.freeze({
  BOTH: "both",
  FORWARD: "forward",
  REVERSED: "reversed",
});

export function layerMatches(filter, handedness) {
  if (filter === LayerFilter.BOTH) return true;
  if (filter === LayerFilter.FORWARD) return handedness === Handedness.FORWARD;
  if (filter === LayerFilter.REVERSED) return handedness === Handedness.REVERSED;
  return true;
}

const EARTH_RADIUS = 6378137;

function toPoint(a, b) {
  if (a === undefined || b === undefined) return null;
  const x = Number(a);
  const y = Number(b);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
  return { x, y };
}

/**
 * Parses an OSM document into nodes, ways and relations.
 *
 * Rejects exactly what the native version rejects: DTD / ENTITY declarations, a root element that
 * is not <osm>, duplicate ids, malformed tags and lanelets carrying two speed_limit tags.
 */
export function parseOsm(text) {
  if (containsDoctypeOrEntity(text)) {
    throw new MapError("为保证本地文件安全，不支持包含 DTD / ENTITY 的 XML。");
  }
  const nodes = new Map();
  const ways = new Map();
  const relations = [];
  const seen = { node: new Set(), way: new Set(), relation: new Set() };
  const stack = [];
  let rootSeen = false;
  let current = null;

  const store = (element) => {
    if (!element) return;
    if (element.kind === "node") {
      const local = toPoint(element.tags.get("local_x"), element.tags.get("local_y"));
      const geo = toPoint(element.lon, element.lat);
      nodes.set(element.id, { local, geo });
    } else if (element.kind === "way") {
      ways.set(element.id, element.refs);
    } else {
      if (element.tags.get("type") === "lanelet" && element.speedTags > 1) {
        throw new MapError(`Lanelet ${element.id} 有多个 speed_limit 标签，请先修复地图。`);
      }
      relations.push({ id: element.id, tags: element.tags, members: element.members });
    }
  };

  scanXml(text, (token) => {
    if (token.closing) {
      if (stack.length === 0) throw new MapError("XML 标签不匹配。");
      const open = stack.pop();
      if (open !== token.name) {
        throw new MapError(`XML 格式错误，第 ${lineAt(text, token.start)} 行：<${open}> 与 </${token.name}> 不匹配。`);
      }
      if (open === "node" || open === "way" || open === "relation") {
        store(current);
        current = null;
      }
      return;
    }
    const attributes = token.attributes ?? {};
    const depth = stack.length;
    const isElement = token.name === "node" || token.name === "way" || token.name === "relation";
    if (depth === 0) {
      if (token.name !== "osm") throw new MapError("文件不是 OSM 地图：根元素应为 <osm>。");
      rootSeen = true;
    } else if (depth === 1 && isElement) {
      const id = attributes.id?.value;
      if (!id) throw new MapError(`发现没有 ID 的 ${token.name}。`);
      if (seen[token.name].has(id)) throw new MapError(`发现重复的 ${token.name} ID：${id}。`);
      seen[token.name].add(id);
      current = {
        kind: token.name,
        id,
        lat: attributes.lat?.value,
        lon: attributes.lon?.value,
        tags: new Map(),
        refs: [],
        members: [],
        speedTags: 0,
      };
    } else if (depth === 2 && current) {
      if (token.name === "tag") {
        const key = attributes.k?.value;
        const value = attributes.v?.value;
        if (key !== undefined && value !== undefined) {
          current.tags.set(key, value);
          if (key === "speed_limit") current.speedTags += 1;
        }
      } else if (token.name === "nd") {
        const ref = attributes.ref?.value;
        if (ref !== undefined) current.refs.push(ref);
      } else if (token.name === "member") {
        current.members.push({
          type: attributes.type?.value ?? "",
          ref: attributes.ref?.value ?? "",
          role: attributes.role?.value ?? "",
        });
      }
    }
    if (token.empty) {
      if (depth === 1 && isElement) {
        store(current);
        current = null;
      }
    } else {
      stack.push(token.name);
    }
  }, PARSER_ATTRIBUTES);

  if (stack.length > 0) throw new MapError("XML 格式错误：有未闭合的标签。");
  if (!rootSeen) throw new MapError("文件不是 OSM 地图：根元素应为 <osm>。");
  return { nodes, ways, relations, rootSeen };
}

/** Validates and normalises a speed string exactly like the native version. */
export function normalizedSpeed(input) {
  const trimmed = String(input ?? "").trim();
  if (!/^[0-9]+(?:\.[0-9]{1,3})?$/.test(trimmed)) {
    throw new MapError("请输入大于 0、且不超过 300 的速度（km/h），最多保留 3 位小数。");
  }
  const speed = Number(trimmed);
  if (!Number.isFinite(speed) || speed <= 0 || speed > 300) {
    throw new MapError("请输入大于 0、且不超过 300 的速度（km/h），最多保留 3 位小数。");
  }
  const [whole, fraction = ""] = trimmed.split(".");
  const normalisedWhole = whole.replace(/^0+(?=\d)/, "");
  const normalisedFraction = fraction.replace(/0+$/, "");
  return normalisedFraction ? `${normalisedWhole}.${normalisedFraction}` : normalisedWhole;
}

export class MapDocument {
  constructor(text) {
    this.source = text;
    const { nodes, ways, relations } = parseOsm(text);
    const lanelets = relations.filter((relation) => relation.tags.get("type") === "lanelet");
    if (lanelets.length === 0) {
      throw new MapError("文件里没有 type=lanelet 的 relation。请选择 Lanelet2 格式的 .osm 文件。");
    }

    const usesLocal = [...nodes.values()].some((node) => node.local !== null);
    const origin = [...nodes.values()].find((node) => node.geo !== null)?.geo ?? { x: 0, y: 0 };
    const radians = Math.PI / 180;
    const coordinate = (node) => {
      if (usesLocal) return node.local;
      if (!node.geo) return null;
      return {
        x: (node.geo.x - origin.x) * radians * EARTH_RADIUS * Math.cos(origin.y * radians),
        y: (node.geo.y - origin.y) * radians * EARTH_RADIUS,
      };
    };
    const points = (wayId) => {
      const refs = wayId === undefined ? undefined : ways.get(wayId);
      if (!refs || refs.length < 2) return [];
      const positions = [];
      for (const ref of refs) {
        const node = nodes.get(ref);
        if (!node) return [];
        const position = coordinate(node);
        if (!position) return [];
        positions.push(position);
      }
      return positions;
    };
    const findMember = (relation, role) => relation.members.find((member) => member.type === "way" && member.role === role)?.ref;

    this.lanes = [];
    let documentBounds = null;
    let conflicts = 0;
    for (const relation of lanelets) {
      const left = points(findMember(relation, "left"));
      const right = points(findMember(relation, "right"));
      let disagrees = false;
      if (left.length > 0 && right.length > 0) {
        const a = left[0];
        const b = left[left.length - 1];
        const c = right[0];
        const d = right[right.length - 1];
        const straight = Math.hypot(a.x - c.x, a.y - c.y) + Math.hypot(b.x - d.x, b.y - d.y);
        const crossed = Math.hypot(a.x - d.x, a.y - d.y) + Math.hypot(b.x - c.x, b.y - c.y);
        if (straight > crossed) {
          right.reverse();
          disagrees = true;
        }
      }
      const polygon = left.length > 0 && right.length > 0 ? left.concat(right.slice().reverse()) : [];
      const bounds = boundsOf(polygon);
      documentBounds = unionBounds(documentBounds, bounds);
      const center = centerline(left, right);
      if (disagrees) conflicts += 1;
      const turnDirection = relation.tags.get("turn_direction");
      const originalSpeed = relation.tags.get("speed_limit");
      this.lanes.push({
        id: relation.id,
        direction: directionOf(turnDirection),
        originalDirection: turnDirection ?? null,
        originalSpeed: originalSpeed ?? null,
        polygon,
        left,
        right,
        centerline: center,
        labelPoint: labelPoint(center, polygon),
        bounds,
        averageWidth: averageWidth(polygon, center, bounds ? Math.min(bounds.width, bounds.height) : 0),
        boundsDisagree: disagrees,
        handedness: handedness(polygon, bounds),
        centerlineLength: lengthOf(center),
      });
    }
    this.bounds = documentBounds;
    this.nodeCount = nodes.size;
    this.wayCount = ways.size;
    this.directionConflictCount = conflicts;
    this.coordinateDescription = usesLocal ? "本地坐标 local_x / local_y" : "经纬度投影（仅用于预览）";
    this.northAngle = usesLocal ? northAngleOf(nodes) : ([...nodes.values()].some((node) => node.geo) ? 0 : null);
    this._pairs = null;
  }

  get drawableCount() {
    return this.lanes.filter((lane) => lane.polygon.length >= 4).length;
  }

  /** Heading a vehicle actually travels at, flipped for reverse-layer lanelets. */
  static effectiveHeading(lane) {
    const stored = storedHeading(lane);
    if (stored === null) return null;
    return lane.handedness === Handedness.REVERSED ? stored + Math.PI : stored;
  }

  /** The path a vehicle follows: the centre line, flipped for reverse-layer lanelets. */
  static travelPath(lane) {
    return lane.handedness === Handedness.REVERSED ? lane.centerline.slice().reverse() : lane.centerline;
  }

  // MARK: - Direction layers

  lanesIn(handedness) {
    return this.lanes.filter((lane) => lane.handedness === handedness);
  }

  lanesForFilter(filter) {
    return this.lanes.filter((lane) => layerMatches(filter, lane.handedness));
  }

  get forwardLayer() { return this.lanesIn(Handedness.FORWARD); }
  get reverseLayer() { return this.lanesIn(Handedness.REVERSED); }
  get undecidedLayer() { return this.lanesIn(Handedness.UNKNOWN); }

  statistics(handedness) {
    const result = { count: 0, length: 0, speeds: {}, turns: {}, conflicts: 0 };
    for (const lane of this.lanesIn(handedness)) {
      result.count += 1;
      result.length += lane.centerlineLength;
      const speed = lane.originalSpeed ?? "未设置";
      result.speeds[speed] = (result.speeds[speed] ?? 0) + 1;
      const turn = directionTitle(lane.direction);
      result.turns[turn] = (result.turns[turn] ?? 0) + 1;
      if (lane.boundsDisagree) result.conflicts += 1;
    }
    return result;
  }

  /**
   * Pairs a reverse-layer lanelet with the forward-layer lanelet covering the same strip. A
   * single-lane two-way map stores both travel directions on the same geometry, so every reverse
   * lanelet should have exactly one forward counterpart.
   */
  reverseLayerPairs(tolerance = 2.0, samples = 13) {
    if (this._pairs) return this._pairs;
    const forwards = this.forwardLayer;
    if (forwards.length === 0) {
      this._pairs = [];
      return this._pairs;
    }
    const side = Math.max(tolerance * 2, 2);
    const grid = new Map();
    const key = (x, y) => `${x},${y}`;
    const sampled = forwards.map((lane) => resample(lane.centerline, samples));
    sampled.forEach((points, laneIndex) => {
      for (const point of points) {
        const cell = key(Math.floor(point.x / side), Math.floor(point.y / side));
        const bucket = grid.get(cell);
        if (bucket) bucket.push({ laneIndex, point });
        else grid.set(cell, [{ laneIndex, point }]);
      }
    });
    const result = [];
    for (const lane of this.reverseLayer) {
      const probes = resample(lane.centerline, samples);
      const hits = new Map();
      for (const probe of probes) {
        const cellX = Math.floor(probe.x / side);
        const cellY = Math.floor(probe.y / side);
        const touched = new Set();
        for (let dx = -2; dx <= 2; dx += 1) {
          for (let dy = -2; dy <= 2; dy += 1) {
            for (const entry of grid.get(key(cellX + dx, cellY + dy)) ?? []) {
              if (Math.hypot(entry.point.x - probe.x, entry.point.y - probe.y) <= tolerance) touched.add(entry.laneIndex);
            }
          }
        }
        for (const laneIndex of touched) hits.set(laneIndex, (hits.get(laneIndex) ?? 0) + 1);
      }
      let bestIndex = -1;
      let bestCount = 0;
      for (const [laneIndex, count] of hits) {
        if (count > bestCount) {
          bestCount = count;
          bestIndex = laneIndex;
        }
      }
      result.push({
        reversed: lane,
        forward: bestIndex >= 0 ? forwards[bestIndex] : null,
        overlap: bestIndex >= 0 ? bestCount / Math.max(probes.length, 1) : 0,
      });
    }
    this._pairs = result;
    return result;
  }

  // MARK: - Export

  /**
   * Rewrites only the speed_limit value spans of the edited lanelets and re-parses the result to
   * prove nothing else moved. Returns the source unchanged when there is nothing to edit.
   */
  export(edits) {
    const entries = edits instanceof Map ? [...edits.entries()] : Object.entries(edits ?? {});
    if (entries.length === 0) return this.source;
    const known = new Set(this.lanes.map((lane) => lane.id));
    for (const [id] of entries) {
      if (!known.has(id)) throw new MapError("修改包含未知的 Lanelet ID。");
    }
    const normalized = new Map();
    for (const [id, value] of entries) normalized.set(id, normalizedSpeed(value));
    const patches = patchesFor(this.source, normalized);
    const output = applyPatches(this.source, patches);
    const checked = new MapDocument(output);
    if (checked.lanes.length !== this.lanes.length
      || checked.nodeCount !== this.nodeCount
      || checked.wayCount !== this.wayCount
      || checked.lanes.some((lane, index) => lane.id !== this.lanes[index].id)) {
      throw new MapError("导出完整性检查失败，未写入文件。");
    }
    for (const lane of checked.lanes) {
      const expected = normalized.get(lane.id);
      if (expected !== undefined && lane.originalSpeed !== expected) {
        throw new MapError(`Lanelet ${lane.id} 的限速写入校验失败。`);
      }
    }
    return output;
  }
}

export function storedHeading(lane) {
  const points = lane.centerline;
  if (points.length < 2) return null;
  const first = points[0];
  const last = points[points.length - 1];
  if (!(Math.hypot(last.x - first.x, last.y - first.y) > 0.001)) return null;
  return Math.atan2(last.y - first.y, last.x - first.x);
}

function northAngleOf(nodes) {
  const paired = [...nodes.values()].filter((node) => node.local && node.geo);
  if (paired.length < 2) return null;
  const ordered = paired.slice().sort((a, b) => a.local.x - b.local.x);
  const first = ordered[0];
  const last = ordered[ordered.length - 1];
  const dx = last.local.x - first.local.x;
  const dy = last.local.y - first.local.y;
  if (!(Math.hypot(dx, dy) > 1)) return null;
  const radians = Math.PI / 180;
  const east = (last.geo.x - first.geo.x) * radians * EARTH_RADIUS * Math.cos(first.geo.y * radians);
  const north = (last.geo.y - first.geo.y) * radians * EARTH_RADIUS;
  if (!(Math.hypot(east, north) > 1)) return null;
  return Math.atan2(north, east) - Math.atan2(dy, dx);
}

/**
 * Works out every span the exporter may touch.
 *
 * A lanelet's speed_limit value span is replaced, or a whole tag is inserted before </relation>
 * when the tag is missing, keeping the file's line endings and indentation.
 */
export function patchesFor(source, edits) {
  const patches = [];
  const modified = new Set();
  const stack = [];
  let target = null;
  let speedFound = false;
  const newline = source.includes("\r\n") ? "\r\n" : "\n";

  scanXml(source, (token) => {
    if (token.closing) {
      const open = stack.pop();
      if (open !== token.name) throw new MapError("XML 标签不匹配。");
      if (open === "relation" && target !== null) {
        const speed = edits.get(target);
        if (speed !== undefined && !speedFound) {
          const lineStart = source.lastIndexOf("\n", token.start - 1) + 1;
          const before = source.slice(lineStart, token.start);
          if (before.trim() === "") {
            patches.push({ start: lineStart, end: lineStart, value: `${before}  <tag k="speed_limit" v="${speed}"/>${newline}` });
          } else {
            patches.push({ start: token.start, end: token.start, value: `<tag k="speed_limit" v="${speed}"/>` });
          }
        }
        if (speed !== undefined) modified.add(target);
        target = null;
      }
      return;
    }
    const depth = stack.length;
    if (depth === 1 && token.name === "relation") {
      const id = token.attributes?.id?.value;
      target = id !== undefined && edits.has(id) ? id : null;
      speedFound = false;
    }
    if (depth === 2 && token.name === "tag" && target !== null
      && token.attributes?.k?.value === "speed_limit" && edits.has(target)) {
      const attribute = token.attributes.v;
      if (speedFound || attribute === undefined) {
        throw new MapError(`Lanelet ${target} 的 speed_limit 标签格式不明确。`);
      }
      patches.push({ start: attribute.start, end: attribute.end, value: edits.get(target) });
      speedFound = true;
    }
    if (!token.empty) stack.push(token.name);
  }, PATCHER_ATTRIBUTES);

  if (modified.size !== edits.size) {
    throw new MapError("无法精确定位所有待修改的 Lanelet，已取消导出。");
  }
  return patches;
}

/**
 * Applies every patch in one pass instead of rebuilding the whole document per edit, which is
 * what made bulk exports slow. Byte for byte the same result.
 */
export function applyPatches(source, patches) {
  if (patches.length === 0) return source;
  const ordered = patches.slice().sort((a, b) => a.start - b.start);
  const chunks = [];
  let cursor = 0;
  for (const patch of ordered) {
    if (patch.start < cursor) throw new MapError("导出修改范围重叠，已取消导出。");
    chunks.push(source.slice(cursor, patch.start), patch.value);
    cursor = patch.end;
  }
  chunks.push(source.slice(cursor));
  return chunks.join("");
}

/** Kept for callers that only need the speed check. */
export { MapError, area, centroid, polygonContains };

// XML scanning shared by the map parser and the byte-exact exporter.
//
// Deliberately dependency free and hand written: it has to run unchanged in Node, in a browser
// and inside Electron, it must never resolve entities, and the exporter needs the exact source
// span of every value it may rewrite. A DOM parser gives none of that.

export class MapError extends Error {
  constructor(message) {
    super(message);
    this.name = "MapError";
  }
}

export const PARSER_ATTRIBUTES = new Set([
  "node", "way", "relation", "tag", "nd", "member",
]);

export const PATCHER_ATTRIBUTES = new Set(["relation", "tag"]);

function isSpace(code) {
  return code === 0x20 || code === 0x09 || code === 0x0a || code === 0x0d;
}

function isSeparator(code) {
  // = < > /
  return code === 0x3d || code === 0x3c || code === 0x3e || code === 0x2f;
}

function matchesIgnoringCase(text, index, pattern) {
  if (index + pattern.length > text.length) return false;
  for (let offset = 0; offset < pattern.length; offset += 1) {
    let a = text.charCodeAt(index + offset);
    if (a >= 0x61 && a <= 0x7a) a -= 0x20;
    let b = pattern.charCodeAt(offset);
    if (b >= 0x61 && b <= 0x7a) b -= 0x20;
    if (a !== b) return false;
  }
  return true;
}

/**
 * True when the document declares a DTD or an entity, in any letter case and anywhere in the
 * file. Scanning for "<!" and comparing six characters is far cheaper than a case-insensitive
 * search over the whole document, and it keeps the same semantics.
 */
export function containsDoctypeOrEntity(text) {
  let index = text.indexOf("<!");
  while (index !== -1) {
    if (matchesIgnoringCase(text, index, "<!doctype") || matchesIgnoringCase(text, index, "<!entity")) {
      return true;
    }
    index = text.indexOf("<!", index + 2);
  }
  return false;
}

const NAMED_ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };

/** Expands the five XML entities and numeric character references. */
export function decodeEntities(value) {
  if (!value.includes("&")) return value;
  return value.replace(/&(#x[0-9a-fA-F]+|#[0-9]+|amp|lt|gt|quot|apos);/g, (match, entity) => {
    if (entity[0] !== "#") return NAMED_ENTITIES[entity] ?? match;
    const code = entity[1] === "x" || entity[1] === "X"
      ? Number.parseInt(entity.slice(2), 16)
      : Number.parseInt(entity.slice(1), 10);
    if (!Number.isFinite(code) || code < 0 || code > 0x10ffff) return match;
    try {
      return String.fromCodePoint(code);
    } catch {
      return match;
    }
  });
}

/**
 * Reads the `name = "value"` pairs of one tag whose element type is wanted.
 *
 * Each entry keeps the absolute span of the value *inside* its quotes, which is the only span
 * the exporter is ever allowed to rewrite.
 */
function readAttributes(text, from, to) {
  const attributes = Object.create(null);
  let index = from;
  // skip the element name
  while (index < to && !isSpace(text.charCodeAt(index)) && !isSeparator(text.charCodeAt(index))) index += 1;
  while (index < to) {
    while (index < to && isSpace(text.charCodeAt(index))) index += 1;
    if (index >= to) break;
    const lead = text.charCodeAt(index);
    if (lead === 0x2f || lead === 0x3e) break; // "/" or ">"
    const nameStart = index;
    while (index < to && !isSpace(text.charCodeAt(index)) && !isSeparator(text.charCodeAt(index))) index += 1;
    if (index === nameStart) {
      index += 1;
      continue;
    }
    const name = text.slice(nameStart, index);
    let probe = index;
    while (probe < to && isSpace(text.charCodeAt(probe))) probe += 1;
    if (probe >= to || text.charCodeAt(probe) !== 0x3d) continue; // bare word, keep scanning
    probe += 1;
    while (probe < to && isSpace(text.charCodeAt(probe))) probe += 1;
    if (probe >= to) break;
    const quote = text.charCodeAt(probe);
    if (quote !== 0x22 && quote !== 0x27) continue; // must be " or '
    probe += 1;
    const valueStart = probe;
    while (probe < to && text.charCodeAt(probe) !== quote) probe += 1;
    if (probe >= to) break; // unterminated value
    attributes[name] = { value: decodeEntities(text.slice(valueStart, probe)), start: valueStart, end: probe };
    index = probe + 1;
  }
  return attributes;
}

/**
 * Walks the document once, calling `onToken` for every element start / end tag.
 *
 * The token object is reused between calls: copy anything you need to keep. Comments, CDATA
 * sections and processing instructions produce no token at all.
 */
export function scanXml(text, onToken, wantedAttributes) {
  const length = text.length;
  const token = { name: "", closing: false, empty: false, start: 0, end: 0, attributes: null };
  let cursor = 0;
  while (cursor < length) {
    const start = text.indexOf("<", cursor);
    if (start === -1) break;
    let terminator = null;
    if (text.startsWith("<!--", start)) terminator = "-->";
    else if (text.startsWith("<![CDATA[", start)) terminator = "]]>";
    else if (text.startsWith("<?", start)) terminator = "?>";
    if (terminator) {
      const end = text.indexOf(terminator, start);
      if (end === -1) throw new MapError("XML 注释或声明不完整。");
      cursor = end + terminator.length;
      continue;
    }
    let end = start + 1;
    let quote = 0;
    while (end < length) {
      const code = text.charCodeAt(end);
      if (quote !== 0) {
        if (code === quote) quote = 0;
      } else if (code === 0x22 || code === 0x27) {
        quote = code;
      } else if (code === 0x3e) {
        break;
      }
      end += 1;
    }
    if (end >= length) throw new MapError("XML 标签不完整。");
    const closing = text.charCodeAt(start + 1) === 0x2f;
    let nameEnd = start + (closing ? 2 : 1);
    const nameStart = nameEnd;
    while (nameEnd < end) {
      const code = text.charCodeAt(nameEnd);
      if (isSpace(code) || isSeparator(code)) break;
      nameEnd += 1;
    }
    token.name = text.slice(nameStart, nameEnd);
    token.closing = closing;
    token.empty = !closing && end > start + 1 && text.charCodeAt(end - 1) === 0x2f;
    token.start = start;
    token.end = end;
    token.attributes = nameEnd > nameStart && wantedAttributes.has(token.name)
      ? readAttributes(text, nameStart, end)
      : null;
    onToken(token);
    cursor = end + 1;
  }
}

/** Line number of an offset, used to make parse errors actionable. */
export function lineAt(text, offset) {
  let line = 1;
  for (let index = 0; index < offset && index < text.length; index += 1) {
    if (text.charCodeAt(index) === 0x0a) line += 1;
  }
  return line;
}

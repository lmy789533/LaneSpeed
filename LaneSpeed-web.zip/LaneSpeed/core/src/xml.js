// XML scanning shared by the map parser and the byte-exact exporter.
//
// Deliberately dependency free and hand written: it has to run unchanged in Node, in a browser
// and inside Electron, it must never resolve entities, and the exporter needs the exact source
// span of every value it may rewrite. A DOM parser gives none of that.

export class MapError extends Error {
  constructor(message) {
    super(message);
    this.name = "MapError";
  }
}

export const PARSER_ATTRIBUTES = new Set([
  "node", "way", "relation", "tag", "nd", "member",
]);

export const PATCHER_ATTRIBUTES = new Set(["relation", "tag"]);

function isSpace(code) {
  return code === 0x20 || code === 0x09 || code === 0x0a || code === 0x0d;
}

function isSeparator(code) {
  // = < > /
  return code === 0x3d || code === 0x3c || code === 0x3e || code === 0x2f;
}

function matchesIgnoringCase(text, index, pattern) {
  if (index + pattern.length > text.length) return false;
  for (let offset = 0; offset < pattern.length; offset += 1) {
    let a = text.charCodeAt(index + offset);
    if (a >= 0x61 && a <= 0x7a) a -= 0x20;
    let b = pattern.charCodeAt(offset);
    if (b >= 0x61 && b <= 0x7a) b -= 0x20;
    if (a !== b) return false;
  }
  return true;
}

/**
 * True when the document declares a DTD or an entity, in any letter case and anywhere in the
 * file. Scanning for "<!" and comparing six characters is far cheaper than a case-insensitive
 * search over the whole document, and it keeps the same semantics.
 */
export function containsDoctypeOrEntity(text) {
  let index = text.indexOf("<!");
  while (index !== -1) {
    if (matchesIgnoringCase(text, index, "<!doctype") || matchesIgnoringCase(text, index, "<!entity")) {
      return true;
    }
    index = text.indexOf("<!", index + 2);
  }
  return false;
}

const NAMED_ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
const XML_NAME = /^[\p{L}_:][\p{L}\p{N}\p{M}_.:\-\u00b7]*$/u;
const validCharacter = (code) => code === 9 || code === 10 || code === 13
  || (code >= 0x20 && code <= 0xd7ff) || (code >= 0xe000 && code <= 0xfffd)
  || (code >= 0x10000 && code <= 0x10ffff);

/**
 * XML 1.0 character check over the whole document.
 *
 * Deliberately a charCodeAt loop: iterating with for..of allocates a string per character and
 * cost 29 ms on a 6.5 MB map versus 10 ms here, while surrogate pairs (an emoji inside a name
 * tag) are still accepted and lone surrogates are still rejected.
 */
function validateCharacters(text) {
  for (let index = 0; index < text.length; index += 1) {
    const code = text.charCodeAt(index);
    if (code === 0x9 || code === 0xa || code === 0xd
      || (code >= 0x20 && code <= 0xd7ff) || (code >= 0xe000 && code <= 0xfffd)) continue;
    if (code >= 0xd800 && code <= 0xdbff) {
      const low = text.charCodeAt(index + 1);
      if (low >= 0xdc00 && low <= 0xdfff) { index += 1; continue; }
    }
    throw new MapError("XML 包含非法字符。");
  }
}

/** Expands the five XML entities and numeric character references. */
export function decodeEntities(value) {
  if (!value.includes("&")) return value;
  if (/&(?!(?:#x[0-9a-fA-F]+|#[0-9]+|amp|lt|gt|quot|apos);)/.test(value)) {
    throw new MapError("XML 包含无效的实体引用。");
  }
  return value.replace(/&(#x[0-9a-fA-F]+|#[0-9]+|amp|lt|gt|quot|apos);/g, (match, entity) => {
    if (entity[0] !== "#") return NAMED_ENTITIES[entity] ?? match;
    const code = entity[1] === "x" || entity[1] === "X"
      ? Number.parseInt(entity.slice(2), 16)
      : Number.parseInt(entity.slice(1), 10);
    if (!Number.isFinite(code) || !validCharacter(code)) throw new MapError("XML 字符引用无效。");
    try {
      return String.fromCodePoint(code);
    } catch {
      return match;
    }
  });
}

/**
 * Reads the `name = "value"` pairs of one tag whose element type is wanted.
 *
 * Each entry keeps the absolute span of the value *inside* its quotes, which is the only span
 * the exporter is ever allowed to rewrite.
 */
function readAttributes(text, from, to) {
  const attributes = Object.create(null);
  let index = from;
  // skip the element name
  while (index < to && !isSpace(text.charCodeAt(index)) && !isSeparator(text.charCodeAt(index))) index += 1;
  while (index < to) {
    const separatorStart = index;
    while (index < to && isSpace(text.charCodeAt(index))) index += 1;
    if (index >= to) break;
    const lead = text.charCodeAt(index);
    if (lead === 0x2f && index === to - 1) break;
    if (index === separatorStart) throw new MapError("XML 属性之间缺少空格。");
    const nameStart = index;
    while (index < to && !isSpace(text.charCodeAt(index)) && !isSeparator(text.charCodeAt(index))) index += 1;
    const name = text.slice(nameStart, index);
    if (!XML_NAME.test(name) || Object.hasOwn(attributes, name)) throw new MapError("XML 属性名无效或重复。");
    let probe = index;
    while (probe < to && isSpace(text.charCodeAt(probe))) probe += 1;
    if (probe >= to || text.charCodeAt(probe) !== 0x3d) throw new MapError("XML 属性缺少等号。");
    probe += 1;
    while (probe < to && isSpace(text.charCodeAt(probe))) probe += 1;
    if (probe >= to) throw new MapError("XML 属性缺少值。");
    const quote = text.charCodeAt(probe);
    if (quote !== 0x22 && quote !== 0x27) throw new MapError("XML 属性值必须用引号包围。");
    probe += 1;
    const valueStart = probe;
    while (probe < to && text.charCodeAt(probe) !== quote) probe += 1;
    if (probe >= to || text.slice(valueStart, probe).includes("<")) throw new MapError("XML 属性值无效。");
    attributes[name] = { value: decodeEntities(text.slice(valueStart, probe)), start: valueStart, end: probe };
    index = probe + 1;
  }
  return attributes;
}

/**
 * Walks the document once, calling `onToken` for every element start / end tag.
 *
 * The token object is reused between calls: copy anything you need to keep. Comments, CDATA
 * sections and processing instructions produce no token at all.
 */
export function scanXml(text, onToken, wantedAttributes, options = {}) {
  const length = text.length;
  // Callers that already validated this exact text (an exporter re-scanning its own source) can
  // skip the pass; the default keeps standalone use safe.
  if (options.validate !== false) validateCharacters(text);
  const token = { name: "", closing: false, empty: false, start: 0, end: 0, attributes: null };
  let cursor = 0;
  let depth = 0;
  while (cursor < length) {
    const start = text.indexOf("<", cursor);
    const gap = text.slice(cursor, start === -1 ? length : start);
    if (depth === 0 && !/^[\x20\t\r\n]*$/.test(cursor === 0 ? gap.replace(/^\uFEFF/, "") : gap)) {
      throw new MapError("XML 根元素之外存在多余内容。");
    }
    if (depth > 0) {
      decodeEntities(gap);
      if (gap.includes("]]>")) throw new MapError("XML 文本包含非法结束标记。");
    }
    if (start === -1) break;
    let terminator = null;
    if (text.startsWith("<!--", start)) terminator = "-->";
    else if (text.startsWith("<![CDATA[", start)) terminator = "]]>";
    else if (text.startsWith("<?", start)) terminator = "?>";
    if (terminator) {
      const end = text.indexOf(terminator, start);
      if (end === -1) throw new MapError("XML 注释或声明不完整。");
      if (terminator === "]]>" && depth === 0) throw new MapError("CDATA 必须位于 XML 根元素中。");
      if (terminator === "-->" && (text.slice(start + 4, end).includes("--") || text[end - 1] === "-")) {
        throw new MapError("XML 注释格式无效。");
      }
      cursor = end + terminator.length;
      continue;
    }
    let end = start + 1;
    let quote = 0;
    while (end < length) {
      const code = text.charCodeAt(end);
      if (quote !== 0) {
        if (code === quote) quote = 0;
      } else if (code === 0x22 || code === 0x27) {
        quote = code;
      } else if (code === 0x3e) {
        break;
      }
      end += 1;
    }
    if (end >= length) throw new MapError("XML 标签不完整。");
    const closing = text.charCodeAt(start + 1) === 0x2f;
    let nameEnd = start + (closing ? 2 : 1);
    const nameStart = nameEnd;
    while (nameEnd < end) {
      const code = text.charCodeAt(nameEnd);
      if (isSpace(code) || isSeparator(code)) break;
      nameEnd += 1;
    }
    token.name = text.slice(nameStart, nameEnd);
    if (!XML_NAME.test(token.name)) throw new MapError("XML 标签名无效。");
    token.closing = closing;
    token.empty = !closing && end > start + 1 && text.charCodeAt(end - 1) === 0x2f;
    token.start = start;
    token.end = end;
    if (closing && text.slice(nameEnd, end).trim() !== "") throw new MapError("XML 结束标签无效。");
    const attributes = closing ? null : readAttributes(text, nameStart, end);
    token.attributes = wantedAttributes.has(token.name) ? attributes : null;
    onToken(token);
    if (closing) depth -= 1;
    else if (!token.empty) depth += 1;
    cursor = end + 1;
  }
}

/** Line number of an offset, used to make parse errors actionable. */
export function lineAt(text, offset) {
  let line = 1;
  for (let index = 0; index < offset && index < text.length; index += 1) {
    if (text.charCodeAt(index) === 0x0a) line += 1;
  }
  return line;
}
